"use strict";

var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Piece = function Piece(_ref, color) {
  var _ref2 = _slicedToArray(_ref, 2),
      x = _ref2[0],
      y = _ref2[1];

  _classCallCheck(this, Piece);

  this.x = x;
  this.y = y;
  this.dead = false;
  if (color === "white") {
    this.color = "white";
  } else if (color === "black") {
    this.color = "black";
  }
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9jb21wb25lbnRzL1BpZWNlcy5qc3giXSwibmFtZXMiOlsiUGllY2UiLCJjb2xvciIsIngiLCJ5IiwiZGVhZCJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0lBQU1BLEssR0FDSixxQkFBb0JDLEtBQXBCLEVBQTJCO0FBQUE7QUFBQSxNQUFkQyxDQUFjO0FBQUEsTUFBWEMsQ0FBVzs7QUFBQTs7QUFDekIsT0FBS0QsQ0FBTCxHQUFTQSxDQUFUO0FBQ0EsT0FBS0MsQ0FBTCxHQUFTQSxDQUFUO0FBQ0EsT0FBS0MsSUFBTCxHQUFZLEtBQVo7QUFDQSxNQUFJSCxVQUFVLE9BQWQsRUFBdUI7QUFDckIsU0FBS0EsS0FBTCxHQUFhLE9BQWI7QUFDRCxHQUZELE1BRU8sSUFBSUEsVUFBVSxPQUFkLEVBQXVCO0FBQzVCLFNBQUtBLEtBQUwsR0FBYSxPQUFiO0FBQ0Q7QUFDRixDIiwiZmlsZSI6IlBpZWNlcy5qcyIsInNvdXJjZXNDb250ZW50IjpbImNsYXNzIFBpZWNlIHtcbiAgY29uc3RydWN0b3IoW3gsIHldLCBjb2xvcikge1xuICAgIHRoaXMueCA9IHg7XG4gICAgdGhpcy55ID0geTtcbiAgICB0aGlzLmRlYWQgPSBmYWxzZTtcbiAgICBpZiAoY29sb3IgPT09IFwid2hpdGVcIikge1xuICAgICAgdGhpcy5jb2xvciA9IFwid2hpdGVcIjtcbiAgICB9IGVsc2UgaWYgKGNvbG9yID09PSBcImJsYWNrXCIpIHtcbiAgICAgIHRoaXMuY29sb3IgPSBcImJsYWNrXCI7XG4gICAgfVxuICB9XG59XG4iXX0=