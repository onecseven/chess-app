"use strict";

var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Rook = function (_Piece) {
  _inherits(Rook, _Piece);

  function Rook(_ref, color) {
    var _ref2 = _slicedToArray(_ref, 2),
        x = _ref2[0],
        y = _ref2[1];

    _classCallCheck(this, Rook);

    var _this = _possibleConstructorReturn(this, (Rook.__proto__ || Object.getPrototypeOf(Rook)).call(this, [x, y], color));

    if (color === "white") {
      _this.symbol = "\u2656";
    } else if (color === "black") {
      _this.symbol = "\u265C";
    }
    _this.type = "rook";
    return _this;
  }

  _createClass(Rook, [{
    key: "possibleMoves",
    value: function possibleMoves() {
      var _this2 = this;

      var range = _.range(8);
      var result1 = [];
      var result2 = [];
      range.forEach(function (i) {
        result1.push([_this2.x, i]);
        result2.push([i, _this2.y]);
      });
      return result1.concat(result2);
    }
  }]);

  return Rook;
}(Piece);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9jb21wb25lbnRzL1Jvb2suanN4Il0sIm5hbWVzIjpbIlJvb2siLCJjb2xvciIsIngiLCJ5Iiwic3ltYm9sIiwidHlwZSIsInJhbmdlIiwiXyIsInJlc3VsdDEiLCJyZXN1bHQyIiwiZm9yRWFjaCIsInB1c2giLCJpIiwiY29uY2F0IiwiUGllY2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztJQUFNQSxJOzs7QUFDSixzQkFBb0JDLEtBQXBCLEVBQTJCO0FBQUE7QUFBQSxRQUFkQyxDQUFjO0FBQUEsUUFBWEMsQ0FBVzs7QUFBQTs7QUFBQSw0R0FDbkIsQ0FBQ0QsQ0FBRCxFQUFJQyxDQUFKLENBRG1CLEVBQ1hGLEtBRFc7O0FBRXpCLFFBQUlBLFVBQVUsT0FBZCxFQUF1QjtBQUNyQixZQUFLRyxNQUFMO0FBQ0QsS0FGRCxNQUVPLElBQUlILFVBQVUsT0FBZCxFQUF1QjtBQUM1QixZQUFLRyxNQUFMO0FBQ0Q7QUFDRCxVQUFLQyxJQUFMLEdBQVksTUFBWjtBQVB5QjtBQVExQjs7OztvQ0FDZTtBQUFBOztBQUNkLFVBQUlDLFFBQVFDLEVBQUVELEtBQUYsQ0FBUSxDQUFSLENBQVo7QUFDQSxVQUFJRSxVQUFVLEVBQWQ7QUFDQSxVQUFJQyxVQUFVLEVBQWQ7QUFDQUgsWUFBTUksT0FBTixDQUFjLGFBQUs7QUFDakJGLGdCQUFRRyxJQUFSLENBQWEsQ0FBQyxPQUFLVCxDQUFOLEVBQVNVLENBQVQsQ0FBYjtBQUNBSCxnQkFBUUUsSUFBUixDQUFhLENBQUNDLENBQUQsRUFBSSxPQUFLVCxDQUFULENBQWI7QUFDRCxPQUhEO0FBSUEsYUFBT0ssUUFBUUssTUFBUixDQUFlSixPQUFmLENBQVA7QUFDRDs7OztFQW5CZ0JLLEsiLCJmaWxlIjoiUm9vay5qcyIsInNvdXJjZXNDb250ZW50IjpbImNsYXNzIFJvb2sgZXh0ZW5kcyBQaWVjZSB7XG4gIGNvbnN0cnVjdG9yKFt4LCB5XSwgY29sb3IpIHtcbiAgICBzdXBlcihbeCwgeV0sIGNvbG9yKTtcbiAgICBpZiAoY29sb3IgPT09IFwid2hpdGVcIikge1xuICAgICAgdGhpcy5zeW1ib2wgPSBg4pmWYDtcbiAgICB9IGVsc2UgaWYgKGNvbG9yID09PSBcImJsYWNrXCIpIHtcbiAgICAgIHRoaXMuc3ltYm9sID0gYOKZnGA7XG4gICAgfVxuICAgIHRoaXMudHlwZSA9IFwicm9va1wiO1xuICB9XG4gIHBvc3NpYmxlTW92ZXMoKSB7XG4gICAgdmFyIHJhbmdlID0gXy5yYW5nZSg4KTtcbiAgICB2YXIgcmVzdWx0MSA9IFtdO1xuICAgIHZhciByZXN1bHQyID0gW107XG4gICAgcmFuZ2UuZm9yRWFjaChpID0+IHtcbiAgICAgIHJlc3VsdDEucHVzaChbdGhpcy54LCBpXSk7XG4gICAgICByZXN1bHQyLnB1c2goW2ksIHRoaXMueV0pO1xuICAgIH0pO1xuICAgIHJldHVybiByZXN1bHQxLmNvbmNhdChyZXN1bHQyKTtcbiAgfVxufVxuIl19