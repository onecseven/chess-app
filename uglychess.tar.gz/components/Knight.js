"use strict";

var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Knight = function (_Piece) {
  _inherits(Knight, _Piece);

  function Knight(_ref, color) {
    var _ref2 = _slicedToArray(_ref, 2),
        x = _ref2[0],
        y = _ref2[1];

    _classCallCheck(this, Knight);

    var _this = _possibleConstructorReturn(this, (Knight.__proto__ || Object.getPrototypeOf(Knight)).call(this, [x, y], color));

    if (color === "white") {
      _this.symbol = "\u2658";
    } else if (color === "black") {
      _this.symbol = "\u265E";
    }
    _this.type = 'knight';
    return _this;
  }

  _createClass(Knight, [{
    key: "possibleMoves",
    value: function possibleMoves() {
      var result = [];
      result.push([this.x + 2, this.y + 1]);
      result.push([this.x + 2, this.y - 1]);
      result.push([this.x - 2, this.y - 1]);
      result.push([this.x - 2, this.y + 1]);
      result.push([this.x + 1, this.y + 2]);
      result.push([this.x + 1, this.y - 2]);
      result.push([this.x - 1, this.y - 2]);
      result.push([this.x - 1, this.y + 2]);
      // console.log('knightX, ', this.x, '\nknightY,', this.y);
      // console.log('KNIGHT: ', result)
      var filtered = result.filter(function (coords) {
        return coords[0] < 8 && coords[0] >= 0 && coords[1] < 8 && coords[1] >= 0;
      });
      return filtered;
    }
  }]);

  return Knight;
}(Piece);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9jb21wb25lbnRzL0tuaWdodC5qc3giXSwibmFtZXMiOlsiS25pZ2h0IiwiY29sb3IiLCJ4IiwieSIsInN5bWJvbCIsInR5cGUiLCJyZXN1bHQiLCJwdXNoIiwiZmlsdGVyZWQiLCJmaWx0ZXIiLCJjb29yZHMiLCJQaWVjZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0lBQU1BLE07OztBQUNKLHdCQUFvQkMsS0FBcEIsRUFBMkI7QUFBQTtBQUFBLFFBQWRDLENBQWM7QUFBQSxRQUFYQyxDQUFXOztBQUFBOztBQUFBLGdIQUNuQixDQUFDRCxDQUFELEVBQUlDLENBQUosQ0FEbUIsRUFDWEYsS0FEVzs7QUFFekIsUUFBSUEsVUFBVSxPQUFkLEVBQXVCO0FBQ3JCLFlBQUtHLE1BQUw7QUFDRCxLQUZELE1BRU8sSUFBSUgsVUFBVSxPQUFkLEVBQXVCO0FBQzVCLFlBQUtHLE1BQUw7QUFDRDtBQUNELFVBQUtDLElBQUwsR0FBWSxRQUFaO0FBUHlCO0FBUTFCOzs7O29DQUNlO0FBQ2QsVUFBSUMsU0FBUyxFQUFiO0FBQ0FBLGFBQU9DLElBQVAsQ0FBWSxDQUFDLEtBQUtMLENBQUwsR0FBUyxDQUFWLEVBQWEsS0FBS0MsQ0FBTCxHQUFTLENBQXRCLENBQVo7QUFDQUcsYUFBT0MsSUFBUCxDQUFZLENBQUMsS0FBS0wsQ0FBTCxHQUFTLENBQVYsRUFBYSxLQUFLQyxDQUFMLEdBQVMsQ0FBdEIsQ0FBWjtBQUNBRyxhQUFPQyxJQUFQLENBQVksQ0FBQyxLQUFLTCxDQUFMLEdBQVMsQ0FBVixFQUFhLEtBQUtDLENBQUwsR0FBUyxDQUF0QixDQUFaO0FBQ0FHLGFBQU9DLElBQVAsQ0FBWSxDQUFDLEtBQUtMLENBQUwsR0FBUyxDQUFWLEVBQWEsS0FBS0MsQ0FBTCxHQUFTLENBQXRCLENBQVo7QUFDQUcsYUFBT0MsSUFBUCxDQUFZLENBQUMsS0FBS0wsQ0FBTCxHQUFTLENBQVYsRUFBYSxLQUFLQyxDQUFMLEdBQVMsQ0FBdEIsQ0FBWjtBQUNBRyxhQUFPQyxJQUFQLENBQVksQ0FBQyxLQUFLTCxDQUFMLEdBQVMsQ0FBVixFQUFhLEtBQUtDLENBQUwsR0FBUyxDQUF0QixDQUFaO0FBQ0FHLGFBQU9DLElBQVAsQ0FBWSxDQUFDLEtBQUtMLENBQUwsR0FBUyxDQUFWLEVBQWEsS0FBS0MsQ0FBTCxHQUFTLENBQXRCLENBQVo7QUFDQUcsYUFBT0MsSUFBUCxDQUFZLENBQUMsS0FBS0wsQ0FBTCxHQUFTLENBQVYsRUFBYSxLQUFLQyxDQUFMLEdBQVMsQ0FBdEIsQ0FBWjtBQUNBO0FBQ0E7QUFDQSxVQUFJSyxXQUFXRixPQUFPRyxNQUFQLENBQWMsa0JBQVU7QUFDckMsZUFBT0MsT0FBTyxDQUFQLElBQVksQ0FBWixJQUFpQkEsT0FBTyxDQUFQLEtBQWEsQ0FBOUIsSUFBbUNBLE9BQU8sQ0FBUCxJQUFZLENBQS9DLElBQW9EQSxPQUFPLENBQVAsS0FBYSxDQUF4RTtBQUNELE9BRmMsQ0FBZjtBQUdBLGFBQU9GLFFBQVA7QUFDRDs7OztFQTFCa0JHLEsiLCJmaWxlIjoiS25pZ2h0LmpzIiwic291cmNlc0NvbnRlbnQiOlsiY2xhc3MgS25pZ2h0IGV4dGVuZHMgUGllY2Uge1xuICBjb25zdHJ1Y3RvcihbeCwgeV0sIGNvbG9yKSB7XG4gICAgc3VwZXIoW3gsIHldLCBjb2xvcik7XG4gICAgaWYgKGNvbG9yID09PSBcIndoaXRlXCIpIHtcbiAgICAgIHRoaXMuc3ltYm9sID0gYOKZmGA7XG4gICAgfSBlbHNlIGlmIChjb2xvciA9PT0gXCJibGFja1wiKSB7XG4gICAgICB0aGlzLnN5bWJvbCA9IGDimZ5gO1xuICAgIH1cbiAgICB0aGlzLnR5cGUgPSAna25pZ2h0JztcbiAgfVxuICBwb3NzaWJsZU1vdmVzKCkge1xuICAgIGxldCByZXN1bHQgPSBbXTtcbiAgICByZXN1bHQucHVzaChbdGhpcy54ICsgMiwgdGhpcy55ICsgMV0pO1xuICAgIHJlc3VsdC5wdXNoKFt0aGlzLnggKyAyLCB0aGlzLnkgLSAxXSk7XG4gICAgcmVzdWx0LnB1c2goW3RoaXMueCAtIDIsIHRoaXMueSAtIDFdKTtcbiAgICByZXN1bHQucHVzaChbdGhpcy54IC0gMiwgdGhpcy55ICsgMV0pO1xuICAgIHJlc3VsdC5wdXNoKFt0aGlzLnggKyAxLCB0aGlzLnkgKyAyXSk7XG4gICAgcmVzdWx0LnB1c2goW3RoaXMueCArIDEsIHRoaXMueSAtIDJdKTtcbiAgICByZXN1bHQucHVzaChbdGhpcy54IC0gMSwgdGhpcy55IC0gMl0pO1xuICAgIHJlc3VsdC5wdXNoKFt0aGlzLnggLSAxLCB0aGlzLnkgKyAyXSk7XG4gICAgLy8gY29uc29sZS5sb2coJ2tuaWdodFgsICcsIHRoaXMueCwgJ1xcbmtuaWdodFksJywgdGhpcy55KTtcbiAgICAvLyBjb25zb2xlLmxvZygnS05JR0hUOiAnLCByZXN1bHQpXG4gICAgbGV0IGZpbHRlcmVkID0gcmVzdWx0LmZpbHRlcihjb29yZHMgPT4ge1xuICAgICAgcmV0dXJuIGNvb3Jkc1swXSA8IDggJiYgY29vcmRzWzBdID49IDAgJiYgY29vcmRzWzFdIDwgOCAmJiBjb29yZHNbMV0gPj0gMFxuICAgIH0pXG4gICAgcmV0dXJuIGZpbHRlcmVkO1xuICB9XG59XG4iXX0=