"use strict";

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var App = function (_React$Component) {
  _inherits(App, _React$Component);

  function App(props) {
    _classCallCheck(this, App);

    var _this = _possibleConstructorReturn(this, (App.__proto__ || Object.getPrototypeOf(App)).call(this, props));

    _this.state = {
      0: new Array(8),
      1: new Array(8),
      2: new Array(8),
      3: new Array(8),
      4: new Array(8),
      5: new Array(8),
      6: new Array(8),
      7: new Array(8),
      showCoords: false
    };
    var rows = Object.keys(_this.state);
    for (var i = 0; i < rows.length; i++) {
      var row = _this.state[rows[i]];
      for (var q = 0; q < row.length; q++) {
        row[q] = new Tile([i, q]);
      }
    }
    // filling chessboard //
    var whitePawns = _this.state[1].slice();
    var blackPawns = _this.state[6].slice();
    for (var _i = 0; _i < whitePawns.length; _i++) {
      var wtile = whitePawns[_i];
      var btile = blackPawns[_i];
      wtile.occupiedBy = new Pawn([1, _i], "white");
      btile.occupiedBy = new Pawn([6, _i], "black");
    }
    _this.state[1] = whitePawns;
    _this.state[6] = blackPawns;
    //fill rooks //
    _this.state[0][0].occupiedBy = new Rook([0, 0], "white");
    _this.state[0][7].occupiedBy = new Rook([0, 7], "white");
    _this.state[7][0].occupiedBy = new Rook([7, 0], "black");
    _this.state[7][1].occupiedBy = new Knight([7, 1], "black");
    _this.state[7][2].occupiedBy = new Bishop([7, 2], "black");
    _this.state[7][3].occupiedBy = new Queen([7, 3], "black");
    _this.state[7][4].occupiedBy = new King([7, 4], "black");
    _this.state[7][5].occupiedBy = new Bishop([7, 5], "black");
    _this.state[7][6].occupiedBy = new Knight([7, 6], "black");
    _this.state[7][7].occupiedBy = new Rook([7, 7], "black");
    _this.state[0][0].occupiedBy = new Rook([0, 0], "white");
    _this.state[0][1].occupiedBy = new Knight([0, 1], "white");
    _this.state[0][2].occupiedBy = new Bishop([0, 2], "white");
    _this.state[0][3].occupiedBy = new Queen([0, 3], "white");
    _this.state[0][4].occupiedBy = new King([0, 4], "white");
    _this.state[0][5].occupiedBy = new Bishop([0, 5], "white");
    _this.state[0][6].occupiedBy = new Knight([0, 6], "white");
    _this.state[0][0].occupiedBy = new Rook([0, 0], "white");
    _this.filterValidMoves = _this.filterValidMoves.bind(_this);
    _this.move = _this.move.bind(_this);
    _this.showCoords = _this.showCoords.bind(_this);
    return _this;
  }

  _createClass(App, [{
    key: "move",
    value: function move(origin, destination) {
      console.log("ORIGIN:", this.state);
      console.log("destination:", this.state[String(destination[0])]);
      var row = this.state[origin[0]].slice();
      var piece = row[origin[1]].occupiedBy;
      piece.x = destination[0];
      piece.y = destination[1];
      row[origin[1]] = new Tile(origin);
      var destRow = this.state[destination[0]].slice();
      destRow[destination[1]].occupiedBy = piece;
      this.setState(_defineProperty({}, origin[0], row));
      this.setState(_defineProperty({}, destination[0], destRow));
    }
  }, {
    key: "showCoords",
    value: function showCoords() {
      if (this.state.showCoords) this.setState({ showCoords: false });else this.setState({ showCoords: true });
    }
  }, {
    key: "filterValidMoves",
    value: function filterValidMoves(coords, moves, color) {
      var debug = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : null;


      var quarking = function quarking(orig, delta) {
        if (delta[0] == orig[0] && delta[1] == orig[1]) {
          return "same";
        }
        //u => -x, =y
        if (delta[0] < orig[0] && orig[1] === delta[1]) {
          return "up";
        }
        //d => +x,=y
        if (delta[0] > orig[0] && orig[1] === delta[1]) {
          return "down";
        }
        //l => =x, -y
        if (delta[0] === orig[0] && orig[1] > delta[1]) {
          return "left";
        }
        //r => =x, +y
        if (delta[0] === orig[0] && orig[1] < delta[1]) {
          return "right";
        }
        //t => -x,-y
        if (delta[0] < orig[0] && delta[1] < orig[1]) {
          return "top";
        }
        //b => +x, +y
        if (delta[0] > orig[0] && delta[1] > orig[1]) {
          return "bottom";
        }
        //c => x+, y-
        if (delta[0] > orig[0] && delta[1] < orig[1]) {
          return "charm";
        }
        //s => x-,y+
        if (delta[0] < orig[0] && delta[1] > orig[1]) {
          return "strange";
        }
        throw Error("problem quarking ORIG: " + orig + ", DELTA: " + delta);
      };

      var quark = {
        up: null,
        down: null,
        left: null,
        right: null,
        top: null,
        bottom: null,
        charm: null,
        strange: null,
        same: true
      };
      var result = [];
      for (var i = 0; i < moves.length; i++) {
        var move = moves[i];
        var piece = this.state[coords[0]][coords[1]].occupiedBy;
        if (move[0] < 0 || move[0] > 7 || move[1] < 0 || move[1] > 7) continue;
        var enemy = this.state[move[0]][move[1]].occupiedBy || null;
        var delta = [move[0] - coords[0], move[1] - coords[1]];
        var direction = quarking(coords, move);
        if (direction === "same") continue;
        if (!enemy && move[0] >= 0 && move[0] <= 7 && move[1] >= 0 && move[1] <= 7 && !quark[direction]) {
          result.push(move);
          continue;
        }
        if (enemy) {
          var enemyColor = enemy.color;
          if (!quark[direction] && enemyColor !== color) {
            quark[direction] = "hostile";
            result.push(move);
            continue;
          } else if (!quark[direction] && enemyColor === color) {
            quark[direction] = "non-hostile";
            continue;
          } else if (quark[direction]) {
            continue;
          }
          // if (piece.type === 'rook') console.log(`legal move ${move} from coords ${coords}. delta direction ${direction}, delta at ${delta}`)
        }
      }
      console.log("QUARKING FOR " + this.state[coords[0]][coords[1]].occupiedBy.type + " at " + coords + " and the quark is:  ");
      console.dir(quark);
      return result;
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var rows = [0, 1, 2, 3, 4, 5, 6, 7];
      return React.createElement(
        "div",
        null,
        React.createElement("div", { className: "App" }),
        React.createElement(
          "div",
          null,
          rows.map(function (row) {
            return React.createElement(
              "div",
              null,
              React.createElement(
                "ul",
                { className: "flex-container" },
                React.createElement(Row, {
                  showCoords: _this2.state.showCoords,
                  filterValidMoves: _this2.filterValidMoves,
                  row: _this2.state[row]
                })
              )
            );
          }),
          React.createElement(Move, { move: this.move, showCoords: this.showCoords })
        )
      );
    }
  }]);

  return App;
}(React.Component);

{}
/* */


// populate() {
//   let array = this.state.board;
//   for (let i = 0; i < array.length; i++) {
//     let elem = array[i];
//     for (let q = 0; q < array.length; q++) {
//       elem[q] = (q+1);
//     }
//   }
// }
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9jb21wb25lbnRzL0FwcC5qc3giXSwibmFtZXMiOlsiQXBwIiwicHJvcHMiLCJzdGF0ZSIsIkFycmF5Iiwic2hvd0Nvb3JkcyIsInJvd3MiLCJPYmplY3QiLCJrZXlzIiwiaSIsImxlbmd0aCIsInJvdyIsInEiLCJUaWxlIiwid2hpdGVQYXducyIsInNsaWNlIiwiYmxhY2tQYXducyIsInd0aWxlIiwiYnRpbGUiLCJvY2N1cGllZEJ5IiwiUGF3biIsIlJvb2siLCJLbmlnaHQiLCJCaXNob3AiLCJRdWVlbiIsIktpbmciLCJmaWx0ZXJWYWxpZE1vdmVzIiwiYmluZCIsIm1vdmUiLCJvcmlnaW4iLCJkZXN0aW5hdGlvbiIsImNvbnNvbGUiLCJsb2ciLCJTdHJpbmciLCJwaWVjZSIsIngiLCJ5IiwiZGVzdFJvdyIsInNldFN0YXRlIiwiY29vcmRzIiwibW92ZXMiLCJjb2xvciIsImRlYnVnIiwicXVhcmtpbmciLCJvcmlnIiwiZGVsdGEiLCJFcnJvciIsInF1YXJrIiwidXAiLCJkb3duIiwibGVmdCIsInJpZ2h0IiwidG9wIiwiYm90dG9tIiwiY2hhcm0iLCJzdHJhbmdlIiwic2FtZSIsInJlc3VsdCIsImVuZW15IiwiZGlyZWN0aW9uIiwicHVzaCIsImVuZW15Q29sb3IiLCJ0eXBlIiwiZGlyIiwibWFwIiwiUmVhY3QiLCJDb21wb25lbnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztJQUFNQSxHOzs7QUFDSixlQUFZQyxLQUFaLEVBQW1CO0FBQUE7O0FBQUEsMEdBQ1hBLEtBRFc7O0FBRWpCLFVBQUtDLEtBQUwsR0FBYTtBQUNYLFNBQUcsSUFBSUMsS0FBSixDQUFVLENBQVYsQ0FEUTtBQUVYLFNBQUcsSUFBSUEsS0FBSixDQUFVLENBQVYsQ0FGUTtBQUdYLFNBQUcsSUFBSUEsS0FBSixDQUFVLENBQVYsQ0FIUTtBQUlYLFNBQUcsSUFBSUEsS0FBSixDQUFVLENBQVYsQ0FKUTtBQUtYLFNBQUcsSUFBSUEsS0FBSixDQUFVLENBQVYsQ0FMUTtBQU1YLFNBQUcsSUFBSUEsS0FBSixDQUFVLENBQVYsQ0FOUTtBQU9YLFNBQUcsSUFBSUEsS0FBSixDQUFVLENBQVYsQ0FQUTtBQVFYLFNBQUcsSUFBSUEsS0FBSixDQUFVLENBQVYsQ0FSUTtBQVNYQyxrQkFBWTtBQVRELEtBQWI7QUFXQSxRQUFJQyxPQUFPQyxPQUFPQyxJQUFQLENBQVksTUFBS0wsS0FBakIsQ0FBWDtBQUNBLFNBQUssSUFBSU0sSUFBSSxDQUFiLEVBQWdCQSxJQUFJSCxLQUFLSSxNQUF6QixFQUFpQ0QsR0FBakMsRUFBc0M7QUFDcEMsVUFBSUUsTUFBTSxNQUFLUixLQUFMLENBQVdHLEtBQUtHLENBQUwsQ0FBWCxDQUFWO0FBQ0EsV0FBSyxJQUFJRyxJQUFJLENBQWIsRUFBZ0JBLElBQUlELElBQUlELE1BQXhCLEVBQWdDRSxHQUFoQyxFQUFxQztBQUNuQ0QsWUFBSUMsQ0FBSixJQUFTLElBQUlDLElBQUosQ0FBUyxDQUFDSixDQUFELEVBQUlHLENBQUosQ0FBVCxDQUFUO0FBQ0Q7QUFDRjtBQUNEO0FBQ0EsUUFBSUUsYUFBYSxNQUFLWCxLQUFMLENBQVcsQ0FBWCxFQUFjWSxLQUFkLEVBQWpCO0FBQ0EsUUFBSUMsYUFBYSxNQUFLYixLQUFMLENBQVcsQ0FBWCxFQUFjWSxLQUFkLEVBQWpCO0FBQ0EsU0FBSyxJQUFJTixLQUFJLENBQWIsRUFBZ0JBLEtBQUlLLFdBQVdKLE1BQS9CLEVBQXVDRCxJQUF2QyxFQUE0QztBQUMxQyxVQUFJUSxRQUFRSCxXQUFXTCxFQUFYLENBQVo7QUFDQSxVQUFJUyxRQUFRRixXQUFXUCxFQUFYLENBQVo7QUFDQVEsWUFBTUUsVUFBTixHQUFtQixJQUFJQyxJQUFKLENBQVMsQ0FBQyxDQUFELEVBQUlYLEVBQUosQ0FBVCxFQUFpQixPQUFqQixDQUFuQjtBQUNBUyxZQUFNQyxVQUFOLEdBQW1CLElBQUlDLElBQUosQ0FBUyxDQUFDLENBQUQsRUFBSVgsRUFBSixDQUFULEVBQWlCLE9BQWpCLENBQW5CO0FBQ0Q7QUFDRCxVQUFLTixLQUFMLENBQVcsQ0FBWCxJQUFnQlcsVUFBaEI7QUFDQSxVQUFLWCxLQUFMLENBQVcsQ0FBWCxJQUFnQmEsVUFBaEI7QUFDQTtBQUNBLFVBQUtiLEtBQUwsQ0FBVyxDQUFYLEVBQWMsQ0FBZCxFQUFpQmdCLFVBQWpCLEdBQThCLElBQUlFLElBQUosQ0FBUyxDQUFDLENBQUQsRUFBSSxDQUFKLENBQVQsRUFBaUIsT0FBakIsQ0FBOUI7QUFDQSxVQUFLbEIsS0FBTCxDQUFXLENBQVgsRUFBYyxDQUFkLEVBQWlCZ0IsVUFBakIsR0FBOEIsSUFBSUUsSUFBSixDQUFTLENBQUMsQ0FBRCxFQUFJLENBQUosQ0FBVCxFQUFpQixPQUFqQixDQUE5QjtBQUNBLFVBQUtsQixLQUFMLENBQVcsQ0FBWCxFQUFjLENBQWQsRUFBaUJnQixVQUFqQixHQUE4QixJQUFJRSxJQUFKLENBQVMsQ0FBQyxDQUFELEVBQUksQ0FBSixDQUFULEVBQWlCLE9BQWpCLENBQTlCO0FBQ0EsVUFBS2xCLEtBQUwsQ0FBVyxDQUFYLEVBQWMsQ0FBZCxFQUFpQmdCLFVBQWpCLEdBQThCLElBQUlHLE1BQUosQ0FBVyxDQUFDLENBQUQsRUFBSSxDQUFKLENBQVgsRUFBbUIsT0FBbkIsQ0FBOUI7QUFDQSxVQUFLbkIsS0FBTCxDQUFXLENBQVgsRUFBYyxDQUFkLEVBQWlCZ0IsVUFBakIsR0FBOEIsSUFBSUksTUFBSixDQUFXLENBQUMsQ0FBRCxFQUFJLENBQUosQ0FBWCxFQUFtQixPQUFuQixDQUE5QjtBQUNBLFVBQUtwQixLQUFMLENBQVcsQ0FBWCxFQUFjLENBQWQsRUFBaUJnQixVQUFqQixHQUE4QixJQUFJSyxLQUFKLENBQVUsQ0FBQyxDQUFELEVBQUksQ0FBSixDQUFWLEVBQWtCLE9BQWxCLENBQTlCO0FBQ0EsVUFBS3JCLEtBQUwsQ0FBVyxDQUFYLEVBQWMsQ0FBZCxFQUFpQmdCLFVBQWpCLEdBQThCLElBQUlNLElBQUosQ0FBUyxDQUFDLENBQUQsRUFBSSxDQUFKLENBQVQsRUFBaUIsT0FBakIsQ0FBOUI7QUFDQSxVQUFLdEIsS0FBTCxDQUFXLENBQVgsRUFBYyxDQUFkLEVBQWlCZ0IsVUFBakIsR0FBOEIsSUFBSUksTUFBSixDQUFXLENBQUMsQ0FBRCxFQUFJLENBQUosQ0FBWCxFQUFtQixPQUFuQixDQUE5QjtBQUNBLFVBQUtwQixLQUFMLENBQVcsQ0FBWCxFQUFjLENBQWQsRUFBaUJnQixVQUFqQixHQUE4QixJQUFJRyxNQUFKLENBQVcsQ0FBQyxDQUFELEVBQUksQ0FBSixDQUFYLEVBQW1CLE9BQW5CLENBQTlCO0FBQ0EsVUFBS25CLEtBQUwsQ0FBVyxDQUFYLEVBQWMsQ0FBZCxFQUFpQmdCLFVBQWpCLEdBQThCLElBQUlFLElBQUosQ0FBUyxDQUFDLENBQUQsRUFBSSxDQUFKLENBQVQsRUFBaUIsT0FBakIsQ0FBOUI7QUFDQSxVQUFLbEIsS0FBTCxDQUFXLENBQVgsRUFBYyxDQUFkLEVBQWlCZ0IsVUFBakIsR0FBOEIsSUFBSUUsSUFBSixDQUFTLENBQUMsQ0FBRCxFQUFJLENBQUosQ0FBVCxFQUFpQixPQUFqQixDQUE5QjtBQUNBLFVBQUtsQixLQUFMLENBQVcsQ0FBWCxFQUFjLENBQWQsRUFBaUJnQixVQUFqQixHQUE4QixJQUFJRyxNQUFKLENBQVcsQ0FBQyxDQUFELEVBQUksQ0FBSixDQUFYLEVBQW1CLE9BQW5CLENBQTlCO0FBQ0EsVUFBS25CLEtBQUwsQ0FBVyxDQUFYLEVBQWMsQ0FBZCxFQUFpQmdCLFVBQWpCLEdBQThCLElBQUlJLE1BQUosQ0FBVyxDQUFDLENBQUQsRUFBSSxDQUFKLENBQVgsRUFBbUIsT0FBbkIsQ0FBOUI7QUFDQSxVQUFLcEIsS0FBTCxDQUFXLENBQVgsRUFBYyxDQUFkLEVBQWlCZ0IsVUFBakIsR0FBOEIsSUFBSUssS0FBSixDQUFVLENBQUMsQ0FBRCxFQUFJLENBQUosQ0FBVixFQUFrQixPQUFsQixDQUE5QjtBQUNBLFVBQUtyQixLQUFMLENBQVcsQ0FBWCxFQUFjLENBQWQsRUFBaUJnQixVQUFqQixHQUE4QixJQUFJTSxJQUFKLENBQVMsQ0FBQyxDQUFELEVBQUksQ0FBSixDQUFULEVBQWlCLE9BQWpCLENBQTlCO0FBQ0EsVUFBS3RCLEtBQUwsQ0FBVyxDQUFYLEVBQWMsQ0FBZCxFQUFpQmdCLFVBQWpCLEdBQThCLElBQUlJLE1BQUosQ0FBVyxDQUFDLENBQUQsRUFBSSxDQUFKLENBQVgsRUFBbUIsT0FBbkIsQ0FBOUI7QUFDQSxVQUFLcEIsS0FBTCxDQUFXLENBQVgsRUFBYyxDQUFkLEVBQWlCZ0IsVUFBakIsR0FBOEIsSUFBSUcsTUFBSixDQUFXLENBQUMsQ0FBRCxFQUFJLENBQUosQ0FBWCxFQUFtQixPQUFuQixDQUE5QjtBQUNBLFVBQUtuQixLQUFMLENBQVcsQ0FBWCxFQUFjLENBQWQsRUFBaUJnQixVQUFqQixHQUE4QixJQUFJRSxJQUFKLENBQVMsQ0FBQyxDQUFELEVBQUksQ0FBSixDQUFULEVBQWlCLE9BQWpCLENBQTlCO0FBQ0EsVUFBS0ssZ0JBQUwsR0FBd0IsTUFBS0EsZ0JBQUwsQ0FBc0JDLElBQXRCLE9BQXhCO0FBQ0EsVUFBS0MsSUFBTCxHQUFZLE1BQUtBLElBQUwsQ0FBVUQsSUFBVixPQUFaO0FBQ0EsVUFBS3RCLFVBQUwsR0FBa0IsTUFBS0EsVUFBTCxDQUFnQnNCLElBQWhCLE9BQWxCO0FBcERpQjtBQXFEbEI7Ozs7eUJBQ0lFLE0sRUFBUUMsVyxFQUFhO0FBQ3hCQyxjQUFRQyxHQUFSLENBQVksU0FBWixFQUF1QixLQUFLN0IsS0FBNUI7QUFDQTRCLGNBQVFDLEdBQVIsQ0FBWSxjQUFaLEVBQTRCLEtBQUs3QixLQUFMLENBQVc4QixPQUFPSCxZQUFZLENBQVosQ0FBUCxDQUFYLENBQTVCO0FBQ0EsVUFBSW5CLE1BQU0sS0FBS1IsS0FBTCxDQUFXMEIsT0FBTyxDQUFQLENBQVgsRUFBc0JkLEtBQXRCLEVBQVY7QUFDQSxVQUFJbUIsUUFBUXZCLElBQUlrQixPQUFPLENBQVAsQ0FBSixFQUFlVixVQUEzQjtBQUNBZSxZQUFNQyxDQUFOLEdBQVVMLFlBQVksQ0FBWixDQUFWO0FBQ0FJLFlBQU1FLENBQU4sR0FBVU4sWUFBWSxDQUFaLENBQVY7QUFDQW5CLFVBQUlrQixPQUFPLENBQVAsQ0FBSixJQUFpQixJQUFJaEIsSUFBSixDQUFTZ0IsTUFBVCxDQUFqQjtBQUNBLFVBQUlRLFVBQVUsS0FBS2xDLEtBQUwsQ0FBVzJCLFlBQVksQ0FBWixDQUFYLEVBQTJCZixLQUEzQixFQUFkO0FBQ0FzQixjQUFRUCxZQUFZLENBQVosQ0FBUixFQUF3QlgsVUFBeEIsR0FBcUNlLEtBQXJDO0FBQ0EsV0FBS0ksUUFBTCxxQkFBaUJULE9BQU8sQ0FBUCxDQUFqQixFQUE2QmxCLEdBQTdCO0FBQ0EsV0FBSzJCLFFBQUwscUJBQWlCUixZQUFZLENBQVosQ0FBakIsRUFBa0NPLE9BQWxDO0FBQ0Q7OztpQ0FDWTtBQUNYLFVBQUksS0FBS2xDLEtBQUwsQ0FBV0UsVUFBZixFQUEyQixLQUFLaUMsUUFBTCxDQUFjLEVBQUVqQyxZQUFZLEtBQWQsRUFBZCxFQUEzQixLQUNLLEtBQUtpQyxRQUFMLENBQWMsRUFBRWpDLFlBQVksSUFBZCxFQUFkO0FBQ047OztxQ0FDZ0JrQyxNLEVBQVFDLEssRUFBT0MsSyxFQUFxQjtBQUFBLFVBQWRDLEtBQWMsdUVBQU4sSUFBTTs7O0FBRW5ELFVBQUlDLFdBQVcsU0FBWEEsUUFBVyxDQUFTQyxJQUFULEVBQWVDLEtBQWYsRUFBc0I7QUFDbkMsWUFBSUEsTUFBTSxDQUFOLEtBQVlELEtBQUssQ0FBTCxDQUFaLElBQXVCQyxNQUFNLENBQU4sS0FBWUQsS0FBSyxDQUFMLENBQXZDLEVBQWdEO0FBQzlDLGlCQUFPLE1BQVA7QUFDRDtBQUNEO0FBQ0EsWUFBSUMsTUFBTSxDQUFOLElBQVdELEtBQUssQ0FBTCxDQUFYLElBQXNCQSxLQUFLLENBQUwsTUFBWUMsTUFBTSxDQUFOLENBQXRDLEVBQWdEO0FBQzlDLGlCQUFPLElBQVA7QUFDRDtBQUNEO0FBQ0EsWUFBSUEsTUFBTSxDQUFOLElBQVdELEtBQUssQ0FBTCxDQUFYLElBQXNCQSxLQUFLLENBQUwsTUFBWUMsTUFBTSxDQUFOLENBQXRDLEVBQWdEO0FBQzlDLGlCQUFPLE1BQVA7QUFDRDtBQUNEO0FBQ0EsWUFBSUEsTUFBTSxDQUFOLE1BQWFELEtBQUssQ0FBTCxDQUFiLElBQXdCQSxLQUFLLENBQUwsSUFBVUMsTUFBTSxDQUFOLENBQXRDLEVBQWdEO0FBQzlDLGlCQUFPLE1BQVA7QUFDRDtBQUNEO0FBQ0EsWUFBSUEsTUFBTSxDQUFOLE1BQWFELEtBQUssQ0FBTCxDQUFiLElBQXdCQSxLQUFLLENBQUwsSUFBVUMsTUFBTSxDQUFOLENBQXRDLEVBQWdEO0FBQzlDLGlCQUFPLE9BQVA7QUFDRDtBQUNEO0FBQ0EsWUFBSUEsTUFBTSxDQUFOLElBQVdELEtBQUssQ0FBTCxDQUFYLElBQXNCQyxNQUFNLENBQU4sSUFBV0QsS0FBSyxDQUFMLENBQXJDLEVBQThDO0FBQzVDLGlCQUFPLEtBQVA7QUFDRDtBQUNEO0FBQ0EsWUFBSUMsTUFBTSxDQUFOLElBQVdELEtBQUssQ0FBTCxDQUFYLElBQXNCQyxNQUFNLENBQU4sSUFBV0QsS0FBSyxDQUFMLENBQXJDLEVBQThDO0FBQzVDLGlCQUFPLFFBQVA7QUFDRDtBQUNEO0FBQ0EsWUFBSUMsTUFBTSxDQUFOLElBQVdELEtBQUssQ0FBTCxDQUFYLElBQXNCQyxNQUFNLENBQU4sSUFBV0QsS0FBSyxDQUFMLENBQXJDLEVBQThDO0FBQzVDLGlCQUFPLE9BQVA7QUFDRDtBQUNEO0FBQ0EsWUFBSUMsTUFBTSxDQUFOLElBQVdELEtBQUssQ0FBTCxDQUFYLElBQXNCQyxNQUFNLENBQU4sSUFBV0QsS0FBSyxDQUFMLENBQXJDLEVBQThDO0FBQzVDLGlCQUFPLFNBQVA7QUFDRDtBQUNELGNBQU1FLGtDQUFnQ0YsSUFBaEMsaUJBQWdEQyxLQUFoRCxDQUFOO0FBQ0QsT0FyQ0Q7O0FBdUNBLFVBQUlFLFFBQVE7QUFDVkMsWUFBSSxJQURNO0FBRVZDLGNBQU0sSUFGSTtBQUdWQyxjQUFNLElBSEk7QUFJVkMsZUFBTyxJQUpHO0FBS1ZDLGFBQUssSUFMSztBQU1WQyxnQkFBUSxJQU5FO0FBT1ZDLGVBQU8sSUFQRztBQVFWQyxpQkFBUyxJQVJDO0FBU1ZDLGNBQU07QUFUSSxPQUFaO0FBV0EsVUFBSUMsU0FBUyxFQUFiO0FBQ0EsV0FBSyxJQUFJaEQsSUFBSSxDQUFiLEVBQWdCQSxJQUFJK0IsTUFBTTlCLE1BQTFCLEVBQWtDRCxHQUFsQyxFQUF1QztBQUNyQyxZQUFNbUIsT0FBT1ksTUFBTS9CLENBQU4sQ0FBYjtBQUNBLFlBQUl5QixRQUFRLEtBQUsvQixLQUFMLENBQVdvQyxPQUFPLENBQVAsQ0FBWCxFQUFzQkEsT0FBTyxDQUFQLENBQXRCLEVBQWlDcEIsVUFBN0M7QUFDQSxZQUFJUyxLQUFLLENBQUwsSUFBVSxDQUFWLElBQWVBLEtBQUssQ0FBTCxJQUFVLENBQXpCLElBQThCQSxLQUFLLENBQUwsSUFBVSxDQUF4QyxJQUE2Q0EsS0FBSyxDQUFMLElBQVUsQ0FBM0QsRUFBOEQ7QUFDOUQsWUFBSThCLFFBQVEsS0FBS3ZELEtBQUwsQ0FBV3lCLEtBQUssQ0FBTCxDQUFYLEVBQW9CQSxLQUFLLENBQUwsQ0FBcEIsRUFBNkJULFVBQTdCLElBQTJDLElBQXZEO0FBQ0EsWUFBSTBCLFFBQVEsQ0FBQ2pCLEtBQUssQ0FBTCxJQUFVVyxPQUFPLENBQVAsQ0FBWCxFQUFzQlgsS0FBSyxDQUFMLElBQVVXLE9BQU8sQ0FBUCxDQUFoQyxDQUFaO0FBQ0EsWUFBSW9CLFlBQVloQixTQUFTSixNQUFULEVBQWlCWCxJQUFqQixDQUFoQjtBQUNBLFlBQUkrQixjQUFjLE1BQWxCLEVBQTBCO0FBQzFCLFlBQ0UsQ0FBQ0QsS0FBRCxJQUNBOUIsS0FBSyxDQUFMLEtBQVcsQ0FEWCxJQUVBQSxLQUFLLENBQUwsS0FBVyxDQUZYLElBR0FBLEtBQUssQ0FBTCxLQUFXLENBSFgsSUFJQUEsS0FBSyxDQUFMLEtBQVcsQ0FKWCxJQUtBLENBQUNtQixNQUFNWSxTQUFOLENBTkgsRUFPRTtBQUNBRixpQkFBT0csSUFBUCxDQUFZaEMsSUFBWjtBQUNBO0FBQ0Q7QUFDRCxZQUFJOEIsS0FBSixFQUFXO0FBQ1QsY0FBSUcsYUFBYUgsTUFBTWpCLEtBQXZCO0FBQ0EsY0FBSSxDQUFDTSxNQUFNWSxTQUFOLENBQUQsSUFBcUJFLGVBQWVwQixLQUF4QyxFQUErQztBQUM3Q00sa0JBQU1ZLFNBQU4sSUFBbUIsU0FBbkI7QUFDQUYsbUJBQU9HLElBQVAsQ0FBWWhDLElBQVo7QUFDQTtBQUNELFdBSkQsTUFJTyxJQUFJLENBQUNtQixNQUFNWSxTQUFOLENBQUQsSUFBcUJFLGVBQWVwQixLQUF4QyxFQUErQztBQUNwRE0sa0JBQU1ZLFNBQU4sSUFBbUIsYUFBbkI7QUFDQTtBQUNELFdBSE0sTUFHQSxJQUFJWixNQUFNWSxTQUFOLENBQUosRUFBc0I7QUFDM0I7QUFDRDtBQUNEO0FBQ0Q7QUFDRjtBQUNENUIsY0FBUUMsR0FBUixtQkFFSSxLQUFLN0IsS0FBTCxDQUFXb0MsT0FBTyxDQUFQLENBQVgsRUFBc0JBLE9BQU8sQ0FBUCxDQUF0QixFQUFpQ3BCLFVBQWpDLENBQTRDMkMsSUFGaEQsWUFHU3ZCLE1BSFQ7QUFLQVIsY0FBUWdDLEdBQVIsQ0FBWWhCLEtBQVo7QUFDQSxhQUFPVSxNQUFQO0FBQ0Q7Ozs2QkFDUTtBQUFBOztBQUNQLFVBQUluRCxPQUFPLENBQUMsQ0FBRCxFQUFJLENBQUosRUFBTyxDQUFQLEVBQVUsQ0FBVixFQUFhLENBQWIsRUFBZ0IsQ0FBaEIsRUFBbUIsQ0FBbkIsRUFBc0IsQ0FBdEIsQ0FBWDtBQUNBLGFBQ0U7QUFBQTtBQUFBO0FBQ0UscUNBQUssV0FBVSxLQUFmLEdBREY7QUFFRTtBQUFBO0FBQUE7QUFDR0EsZUFBSzBELEdBQUwsQ0FBUyxlQUFPO0FBQ2YsbUJBQ0U7QUFBQTtBQUFBO0FBQ0U7QUFBQTtBQUFBLGtCQUFJLFdBQVUsZ0JBQWQ7QUFDRSxvQ0FBQyxHQUFEO0FBQ0UsOEJBQVksT0FBSzdELEtBQUwsQ0FBV0UsVUFEekI7QUFFRSxvQ0FBa0IsT0FBS3FCLGdCQUZ6QjtBQUdFLHVCQUFLLE9BQUt2QixLQUFMLENBQVdRLEdBQVg7QUFIUDtBQURGO0FBREYsYUFERjtBQVdELFdBWkEsQ0FESDtBQWNFLDhCQUFDLElBQUQsSUFBTSxNQUFNLEtBQUtpQixJQUFqQixFQUF1QixZQUFZLEtBQUt2QixVQUF4QztBQWRGO0FBRkYsT0FERjtBQXFCRDs7OztFQTlMZTRELE1BQU1DLFM7O0FBaU14QixDQUVDO0FBREM7OztBQUdGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJBcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJjbGFzcyBBcHAgZXh0ZW5kcyBSZWFjdC5Db21wb25lbnQge1xuICBjb25zdHJ1Y3Rvcihwcm9wcykge1xuICAgIHN1cGVyKHByb3BzKTtcbiAgICB0aGlzLnN0YXRlID0ge1xuICAgICAgMDogbmV3IEFycmF5KDgpLFxuICAgICAgMTogbmV3IEFycmF5KDgpLFxuICAgICAgMjogbmV3IEFycmF5KDgpLFxuICAgICAgMzogbmV3IEFycmF5KDgpLFxuICAgICAgNDogbmV3IEFycmF5KDgpLFxuICAgICAgNTogbmV3IEFycmF5KDgpLFxuICAgICAgNjogbmV3IEFycmF5KDgpLFxuICAgICAgNzogbmV3IEFycmF5KDgpLFxuICAgICAgc2hvd0Nvb3JkczogZmFsc2VcbiAgICB9O1xuICAgIHZhciByb3dzID0gT2JqZWN0LmtleXModGhpcy5zdGF0ZSk7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCByb3dzLmxlbmd0aDsgaSsrKSB7XG4gICAgICBsZXQgcm93ID0gdGhpcy5zdGF0ZVtyb3dzW2ldXTtcbiAgICAgIGZvciAobGV0IHEgPSAwOyBxIDwgcm93Lmxlbmd0aDsgcSsrKSB7XG4gICAgICAgIHJvd1txXSA9IG5ldyBUaWxlKFtpLCBxXSk7XG4gICAgICB9XG4gICAgfVxuICAgIC8vIGZpbGxpbmcgY2hlc3Nib2FyZCAvL1xuICAgIGxldCB3aGl0ZVBhd25zID0gdGhpcy5zdGF0ZVsxXS5zbGljZSgpO1xuICAgIGxldCBibGFja1Bhd25zID0gdGhpcy5zdGF0ZVs2XS5zbGljZSgpO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgd2hpdGVQYXducy5sZW5ndGg7IGkrKykge1xuICAgICAgbGV0IHd0aWxlID0gd2hpdGVQYXduc1tpXTtcbiAgICAgIGxldCBidGlsZSA9IGJsYWNrUGF3bnNbaV07XG4gICAgICB3dGlsZS5vY2N1cGllZEJ5ID0gbmV3IFBhd24oWzEsIGldLCBcIndoaXRlXCIpO1xuICAgICAgYnRpbGUub2NjdXBpZWRCeSA9IG5ldyBQYXduKFs2LCBpXSwgXCJibGFja1wiKTtcbiAgICB9XG4gICAgdGhpcy5zdGF0ZVsxXSA9IHdoaXRlUGF3bnM7XG4gICAgdGhpcy5zdGF0ZVs2XSA9IGJsYWNrUGF3bnM7XG4gICAgLy9maWxsIHJvb2tzIC8vXG4gICAgdGhpcy5zdGF0ZVswXVswXS5vY2N1cGllZEJ5ID0gbmV3IFJvb2soWzAsIDBdLCBcIndoaXRlXCIpO1xuICAgIHRoaXMuc3RhdGVbMF1bN10ub2NjdXBpZWRCeSA9IG5ldyBSb29rKFswLCA3XSwgXCJ3aGl0ZVwiKTtcbiAgICB0aGlzLnN0YXRlWzddWzBdLm9jY3VwaWVkQnkgPSBuZXcgUm9vayhbNywgMF0sIFwiYmxhY2tcIik7XG4gICAgdGhpcy5zdGF0ZVs3XVsxXS5vY2N1cGllZEJ5ID0gbmV3IEtuaWdodChbNywgMV0sIFwiYmxhY2tcIik7XG4gICAgdGhpcy5zdGF0ZVs3XVsyXS5vY2N1cGllZEJ5ID0gbmV3IEJpc2hvcChbNywgMl0sIFwiYmxhY2tcIik7XG4gICAgdGhpcy5zdGF0ZVs3XVszXS5vY2N1cGllZEJ5ID0gbmV3IFF1ZWVuKFs3LCAzXSwgXCJibGFja1wiKTtcbiAgICB0aGlzLnN0YXRlWzddWzRdLm9jY3VwaWVkQnkgPSBuZXcgS2luZyhbNywgNF0sIFwiYmxhY2tcIik7XG4gICAgdGhpcy5zdGF0ZVs3XVs1XS5vY2N1cGllZEJ5ID0gbmV3IEJpc2hvcChbNywgNV0sIFwiYmxhY2tcIik7XG4gICAgdGhpcy5zdGF0ZVs3XVs2XS5vY2N1cGllZEJ5ID0gbmV3IEtuaWdodChbNywgNl0sIFwiYmxhY2tcIik7XG4gICAgdGhpcy5zdGF0ZVs3XVs3XS5vY2N1cGllZEJ5ID0gbmV3IFJvb2soWzcsIDddLCBcImJsYWNrXCIpO1xuICAgIHRoaXMuc3RhdGVbMF1bMF0ub2NjdXBpZWRCeSA9IG5ldyBSb29rKFswLCAwXSwgXCJ3aGl0ZVwiKTtcbiAgICB0aGlzLnN0YXRlWzBdWzFdLm9jY3VwaWVkQnkgPSBuZXcgS25pZ2h0KFswLCAxXSwgXCJ3aGl0ZVwiKTtcbiAgICB0aGlzLnN0YXRlWzBdWzJdLm9jY3VwaWVkQnkgPSBuZXcgQmlzaG9wKFswLCAyXSwgXCJ3aGl0ZVwiKTtcbiAgICB0aGlzLnN0YXRlWzBdWzNdLm9jY3VwaWVkQnkgPSBuZXcgUXVlZW4oWzAsIDNdLCBcIndoaXRlXCIpO1xuICAgIHRoaXMuc3RhdGVbMF1bNF0ub2NjdXBpZWRCeSA9IG5ldyBLaW5nKFswLCA0XSwgXCJ3aGl0ZVwiKTtcbiAgICB0aGlzLnN0YXRlWzBdWzVdLm9jY3VwaWVkQnkgPSBuZXcgQmlzaG9wKFswLCA1XSwgXCJ3aGl0ZVwiKTtcbiAgICB0aGlzLnN0YXRlWzBdWzZdLm9jY3VwaWVkQnkgPSBuZXcgS25pZ2h0KFswLCA2XSwgXCJ3aGl0ZVwiKTtcbiAgICB0aGlzLnN0YXRlWzBdWzBdLm9jY3VwaWVkQnkgPSBuZXcgUm9vayhbMCwgMF0sIFwid2hpdGVcIik7XG4gICAgdGhpcy5maWx0ZXJWYWxpZE1vdmVzID0gdGhpcy5maWx0ZXJWYWxpZE1vdmVzLmJpbmQodGhpcyk7XG4gICAgdGhpcy5tb3ZlID0gdGhpcy5tb3ZlLmJpbmQodGhpcyk7XG4gICAgdGhpcy5zaG93Q29vcmRzID0gdGhpcy5zaG93Q29vcmRzLmJpbmQodGhpcyk7XG4gIH1cbiAgbW92ZShvcmlnaW4sIGRlc3RpbmF0aW9uKSB7XG4gICAgY29uc29sZS5sb2coXCJPUklHSU46XCIsIHRoaXMuc3RhdGUpO1xuICAgIGNvbnNvbGUubG9nKFwiZGVzdGluYXRpb246XCIsIHRoaXMuc3RhdGVbU3RyaW5nKGRlc3RpbmF0aW9uWzBdKV0pO1xuICAgIGxldCByb3cgPSB0aGlzLnN0YXRlW29yaWdpblswXV0uc2xpY2UoKTtcbiAgICBsZXQgcGllY2UgPSByb3dbb3JpZ2luWzFdXS5vY2N1cGllZEJ5O1xuICAgIHBpZWNlLnggPSBkZXN0aW5hdGlvblswXTtcbiAgICBwaWVjZS55ID0gZGVzdGluYXRpb25bMV07XG4gICAgcm93W29yaWdpblsxXV0gPSBuZXcgVGlsZShvcmlnaW4pO1xuICAgIGxldCBkZXN0Um93ID0gdGhpcy5zdGF0ZVtkZXN0aW5hdGlvblswXV0uc2xpY2UoKTtcbiAgICBkZXN0Um93W2Rlc3RpbmF0aW9uWzFdXS5vY2N1cGllZEJ5ID0gcGllY2U7XG4gICAgdGhpcy5zZXRTdGF0ZSh7IFtvcmlnaW5bMF1dOiByb3cgfSk7XG4gICAgdGhpcy5zZXRTdGF0ZSh7IFtkZXN0aW5hdGlvblswXV06IGRlc3RSb3cgfSk7XG4gIH1cbiAgc2hvd0Nvb3JkcygpIHtcbiAgICBpZiAodGhpcy5zdGF0ZS5zaG93Q29vcmRzKSB0aGlzLnNldFN0YXRlKHsgc2hvd0Nvb3JkczogZmFsc2UgfSk7XG4gICAgZWxzZSB0aGlzLnNldFN0YXRlKHsgc2hvd0Nvb3JkczogdHJ1ZSB9KTtcbiAgfVxuICBmaWx0ZXJWYWxpZE1vdmVzKGNvb3JkcywgbW92ZXMsIGNvbG9yLCBkZWJ1ZyA9IG51bGwpIHtcblxuICAgIHZhciBxdWFya2luZyA9IGZ1bmN0aW9uKG9yaWcsIGRlbHRhKSB7XG4gICAgICBpZiAoZGVsdGFbMF0gPT0gb3JpZ1swXSAmJiBkZWx0YVsxXSA9PSBvcmlnWzFdKSB7XG4gICAgICAgIHJldHVybiBcInNhbWVcIjtcbiAgICAgIH1cbiAgICAgIC8vdSA9PiAteCwgPXlcbiAgICAgIGlmIChkZWx0YVswXSA8IG9yaWdbMF0gJiYgb3JpZ1sxXSA9PT0gZGVsdGFbMV0pIHtcbiAgICAgICAgcmV0dXJuIFwidXBcIjtcbiAgICAgIH1cbiAgICAgIC8vZCA9PiAreCw9eVxuICAgICAgaWYgKGRlbHRhWzBdID4gb3JpZ1swXSAmJiBvcmlnWzFdID09PSBkZWx0YVsxXSkge1xuICAgICAgICByZXR1cm4gXCJkb3duXCI7XG4gICAgICB9XG4gICAgICAvL2wgPT4gPXgsIC15XG4gICAgICBpZiAoZGVsdGFbMF0gPT09IG9yaWdbMF0gJiYgb3JpZ1sxXSA+IGRlbHRhWzFdKSB7XG4gICAgICAgIHJldHVybiBcImxlZnRcIjtcbiAgICAgIH1cbiAgICAgIC8vciA9PiA9eCwgK3lcbiAgICAgIGlmIChkZWx0YVswXSA9PT0gb3JpZ1swXSAmJiBvcmlnWzFdIDwgZGVsdGFbMV0pIHtcbiAgICAgICAgcmV0dXJuIFwicmlnaHRcIjtcbiAgICAgIH1cbiAgICAgIC8vdCA9PiAteCwteVxuICAgICAgaWYgKGRlbHRhWzBdIDwgb3JpZ1swXSAmJiBkZWx0YVsxXSA8IG9yaWdbMV0pIHtcbiAgICAgICAgcmV0dXJuIFwidG9wXCI7XG4gICAgICB9XG4gICAgICAvL2IgPT4gK3gsICt5XG4gICAgICBpZiAoZGVsdGFbMF0gPiBvcmlnWzBdICYmIGRlbHRhWzFdID4gb3JpZ1sxXSkge1xuICAgICAgICByZXR1cm4gXCJib3R0b21cIjtcbiAgICAgIH1cbiAgICAgIC8vYyA9PiB4KywgeS1cbiAgICAgIGlmIChkZWx0YVswXSA+IG9yaWdbMF0gJiYgZGVsdGFbMV0gPCBvcmlnWzFdKSB7XG4gICAgICAgIHJldHVybiBcImNoYXJtXCI7XG4gICAgICB9XG4gICAgICAvL3MgPT4geC0seStcbiAgICAgIGlmIChkZWx0YVswXSA8IG9yaWdbMF0gJiYgZGVsdGFbMV0gPiBvcmlnWzFdKSB7XG4gICAgICAgIHJldHVybiBcInN0cmFuZ2VcIjtcbiAgICAgIH1cbiAgICAgIHRocm93IEVycm9yKGBwcm9ibGVtIHF1YXJraW5nIE9SSUc6ICR7b3JpZ30sIERFTFRBOiAke2RlbHRhfWApO1xuICAgIH07XG5cbiAgICBsZXQgcXVhcmsgPSB7XG4gICAgICB1cDogbnVsbCxcbiAgICAgIGRvd246IG51bGwsXG4gICAgICBsZWZ0OiBudWxsLFxuICAgICAgcmlnaHQ6IG51bGwsXG4gICAgICB0b3A6IG51bGwsXG4gICAgICBib3R0b206IG51bGwsXG4gICAgICBjaGFybTogbnVsbCxcbiAgICAgIHN0cmFuZ2U6IG51bGwsXG4gICAgICBzYW1lOiB0cnVlXG4gICAgfTtcbiAgICBsZXQgcmVzdWx0ID0gW107XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBtb3Zlcy5sZW5ndGg7IGkrKykge1xuICAgICAgY29uc3QgbW92ZSA9IG1vdmVzW2ldO1xuICAgICAgbGV0IHBpZWNlID0gdGhpcy5zdGF0ZVtjb29yZHNbMF1dW2Nvb3Jkc1sxXV0ub2NjdXBpZWRCeTtcbiAgICAgIGlmIChtb3ZlWzBdIDwgMCB8fCBtb3ZlWzBdID4gNyB8fCBtb3ZlWzFdIDwgMCB8fCBtb3ZlWzFdID4gNykgY29udGludWU7XG4gICAgICBsZXQgZW5lbXkgPSB0aGlzLnN0YXRlW21vdmVbMF1dW21vdmVbMV1dLm9jY3VwaWVkQnkgfHwgbnVsbDtcbiAgICAgIGxldCBkZWx0YSA9IFttb3ZlWzBdIC0gY29vcmRzWzBdLCBtb3ZlWzFdIC0gY29vcmRzWzFdXTtcbiAgICAgIGxldCBkaXJlY3Rpb24gPSBxdWFya2luZyhjb29yZHMsIG1vdmUpO1xuICAgICAgaWYgKGRpcmVjdGlvbiA9PT0gXCJzYW1lXCIpIGNvbnRpbnVlO1xuICAgICAgaWYgKFxuICAgICAgICAhZW5lbXkgJiZcbiAgICAgICAgbW92ZVswXSA+PSAwICYmXG4gICAgICAgIG1vdmVbMF0gPD0gNyAmJlxuICAgICAgICBtb3ZlWzFdID49IDAgJiZcbiAgICAgICAgbW92ZVsxXSA8PSA3ICYmXG4gICAgICAgICFxdWFya1tkaXJlY3Rpb25dXG4gICAgICApIHtcbiAgICAgICAgcmVzdWx0LnB1c2gobW92ZSk7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgaWYgKGVuZW15KSB7XG4gICAgICAgIGxldCBlbmVteUNvbG9yID0gZW5lbXkuY29sb3I7XG4gICAgICAgIGlmICghcXVhcmtbZGlyZWN0aW9uXSAmJiBlbmVteUNvbG9yICE9PSBjb2xvcikge1xuICAgICAgICAgIHF1YXJrW2RpcmVjdGlvbl0gPSBcImhvc3RpbGVcIjtcbiAgICAgICAgICByZXN1bHQucHVzaChtb3ZlKTtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfSBlbHNlIGlmICghcXVhcmtbZGlyZWN0aW9uXSAmJiBlbmVteUNvbG9yID09PSBjb2xvcikge1xuICAgICAgICAgIHF1YXJrW2RpcmVjdGlvbl0gPSBcIm5vbi1ob3N0aWxlXCI7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH0gZWxzZSBpZiAocXVhcmtbZGlyZWN0aW9uXSkge1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIC8vIGlmIChwaWVjZS50eXBlID09PSAncm9vaycpIGNvbnNvbGUubG9nKGBsZWdhbCBtb3ZlICR7bW92ZX0gZnJvbSBjb29yZHMgJHtjb29yZHN9LiBkZWx0YSBkaXJlY3Rpb24gJHtkaXJlY3Rpb259LCBkZWx0YSBhdCAke2RlbHRhfWApXG4gICAgICB9XG4gICAgfVxuICAgIGNvbnNvbGUubG9nKFxuICAgICAgYFFVQVJLSU5HIEZPUiAke1xuICAgICAgICB0aGlzLnN0YXRlW2Nvb3Jkc1swXV1bY29vcmRzWzFdXS5vY2N1cGllZEJ5LnR5cGVcbiAgICAgIH0gYXQgJHtjb29yZHN9IGFuZCB0aGUgcXVhcmsgaXM6ICBgXG4gICAgKTtcbiAgICBjb25zb2xlLmRpcihxdWFyayk7XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfVxuICByZW5kZXIoKSB7XG4gICAgdmFyIHJvd3MgPSBbMCwgMSwgMiwgMywgNCwgNSwgNiwgN107XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiQXBwXCIgLz5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICB7cm93cy5tYXAocm93ID0+IHtcbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImZsZXgtY29udGFpbmVyXCI+XG4gICAgICAgICAgICAgICAgICA8Um93XG4gICAgICAgICAgICAgICAgICAgIHNob3dDb29yZHM9e3RoaXMuc3RhdGUuc2hvd0Nvb3Jkc31cbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyVmFsaWRNb3Zlcz17dGhpcy5maWx0ZXJWYWxpZE1vdmVzfVxuICAgICAgICAgICAgICAgICAgICByb3c9e3RoaXMuc3RhdGVbcm93XX1cbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0pfVxuICAgICAgICAgIDxNb3ZlIG1vdmU9e3RoaXMubW92ZX0gc2hvd0Nvb3Jkcz17dGhpcy5zaG93Q29vcmRzfSAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cbn1cblxue1xuICAvKiAqL1xufVxuXG4vLyBwb3B1bGF0ZSgpIHtcbi8vICAgbGV0IGFycmF5ID0gdGhpcy5zdGF0ZS5ib2FyZDtcbi8vICAgZm9yIChsZXQgaSA9IDA7IGkgPCBhcnJheS5sZW5ndGg7IGkrKykge1xuLy8gICAgIGxldCBlbGVtID0gYXJyYXlbaV07XG4vLyAgICAgZm9yIChsZXQgcSA9IDA7IHEgPCBhcnJheS5sZW5ndGg7IHErKykge1xuLy8gICAgICAgZWxlbVtxXSA9IChxKzEpO1xuLy8gICAgIH1cbi8vICAgfVxuLy8gfVxuIl19