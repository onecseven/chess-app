"use strict";

var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Pawn = function (_Piece) {
  _inherits(Pawn, _Piece);

  function Pawn(_ref, color) {
    var _ref2 = _slicedToArray(_ref, 2),
        x = _ref2[0],
        y = _ref2[1];

    _classCallCheck(this, Pawn);

    var _this = _possibleConstructorReturn(this, (Pawn.__proto__ || Object.getPrototypeOf(Pawn)).call(this, [x, y], color));

    if (color === "white") {
      _this.symbol = "\u2659";
    } else if (color === "black") {
      _this.symbol = "\u265F";
    }
    _this.type = 'pawn';
    return _this;
  }

  _createClass(Pawn, [{
    key: "possibleMoves",
    value: function possibleMoves() {
      if (this.color === "white") {
        return [[this.x + 1, this.y]];
      } else if (this.color === "black") {
        return [[this.x - 1, this.y]];
      }
    }
  }]);

  return Pawn;
}(Piece);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9jb21wb25lbnRzL1Bhd25zLmpzeCJdLCJuYW1lcyI6WyJQYXduIiwiY29sb3IiLCJ4IiwieSIsInN5bWJvbCIsInR5cGUiLCJQaWVjZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0lBQU1BLEk7OztBQUNKLHNCQUFvQkMsS0FBcEIsRUFBMkI7QUFBQTtBQUFBLFFBQWRDLENBQWM7QUFBQSxRQUFYQyxDQUFXOztBQUFBOztBQUFBLDRHQUNuQixDQUFDRCxDQUFELEVBQUlDLENBQUosQ0FEbUIsRUFDWEYsS0FEVzs7QUFFekIsUUFBSUEsVUFBVSxPQUFkLEVBQXVCO0FBQ3JCLFlBQUtHLE1BQUw7QUFDRCxLQUZELE1BRU8sSUFBSUgsVUFBVSxPQUFkLEVBQXVCO0FBQzVCLFlBQUtHLE1BQUw7QUFDRDtBQUNELFVBQUtDLElBQUwsR0FBWSxNQUFaO0FBUHlCO0FBUTFCOzs7O29DQUNlO0FBQ2QsVUFBSSxLQUFLSixLQUFMLEtBQWUsT0FBbkIsRUFBNEI7QUFDMUIsZUFBTyxDQUFDLENBQUMsS0FBS0MsQ0FBTCxHQUFTLENBQVYsRUFBYSxLQUFLQyxDQUFsQixDQUFELENBQVA7QUFDRCxPQUZELE1BRU8sSUFBSSxLQUFLRixLQUFMLEtBQWUsT0FBbkIsRUFBNEI7QUFDakMsZUFBTyxDQUFDLENBQUMsS0FBS0MsQ0FBTCxHQUFTLENBQVYsRUFBYSxLQUFLQyxDQUFsQixDQUFELENBQVA7QUFDRDtBQUNGOzs7O0VBaEJnQkcsSyIsImZpbGUiOiJQYXducy5qcyIsInNvdXJjZXNDb250ZW50IjpbImNsYXNzIFBhd24gZXh0ZW5kcyBQaWVjZSB7XG4gIGNvbnN0cnVjdG9yKFt4LCB5XSwgY29sb3IpIHtcbiAgICBzdXBlcihbeCwgeV0sIGNvbG9yKTtcbiAgICBpZiAoY29sb3IgPT09IFwid2hpdGVcIikge1xuICAgICAgdGhpcy5zeW1ib2wgPSBg4pmZYDtcbiAgICB9IGVsc2UgaWYgKGNvbG9yID09PSBcImJsYWNrXCIpIHtcbiAgICAgIHRoaXMuc3ltYm9sID0gYOKZn2A7XG4gICAgfVxuICAgIHRoaXMudHlwZSA9ICdwYXduJztcbiAgfVxuICBwb3NzaWJsZU1vdmVzKCkge1xuICAgIGlmICh0aGlzLmNvbG9yID09PSBcIndoaXRlXCIpIHtcbiAgICAgIHJldHVybiBbW3RoaXMueCArIDEsIHRoaXMueV1dO1xuICAgIH0gZWxzZSBpZiAodGhpcy5jb2xvciA9PT0gXCJibGFja1wiKSB7XG4gICAgICByZXR1cm4gW1t0aGlzLnggLSAxLCB0aGlzLnldXTtcbiAgICB9XG4gIH1cbn1cbiJdfQ==