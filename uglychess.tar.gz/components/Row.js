"use strict";

var Row = function Row(_ref) {
  var row = _ref.row,
      filterValidMoves = _ref.filterValidMoves,
      showCoords = _ref.showCoords;

  console.log(row);
  return React.createElement(
    "p",
    null,
    row.map(function (tile) {
      /*
      TODO:
      2. tile on hover should show where the chess pieces can move by highlighting those tiles blue.
      3. tile on click should leave the highlights permanently.
      4. highlighted tile click should move the piece there
      */
      var coords = tile.coords();
      var text = coords;
      var chessBoardTile = "flex-item ";
      var tooltip = text;
      var symbol;
      if (showCoords) var symbol = "[" + String(coords) + "]";
      if (tile.color === "black") {
        chessBoardTile += "black-tile";
      } else if (tile.color === "white") {
        chessBoardTile += "white-tile";
      }
      if (tile.occupiedBy) {
        symbol = tile.occupiedBy.symbol;
        var piece = tile.occupiedBy.type;
        tooltip = filterValidMoves(coords, tile.occupiedBy.possibleMoves(), tile.color);
        if (piece === 'king') {
          tooltip = filterValidMoves(coords, tile.occupiedBy.possibleMoves(), tile.color, true);
        }
      } else {
        //var symbol = text;
      }
      return React.createElement(
        "li",
        { className: chessBoardTile, title: tooltip },
        symbol
      );
    })
  );
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9jb21wb25lbnRzL1Jvdy5qc3giXSwibmFtZXMiOlsiUm93Iiwicm93IiwiZmlsdGVyVmFsaWRNb3ZlcyIsInNob3dDb29yZHMiLCJjb25zb2xlIiwibG9nIiwibWFwIiwiY29vcmRzIiwidGlsZSIsInRleHQiLCJjaGVzc0JvYXJkVGlsZSIsInRvb2x0aXAiLCJzeW1ib2wiLCJTdHJpbmciLCJjb2xvciIsIm9jY3VwaWVkQnkiLCJwaWVjZSIsInR5cGUiLCJwb3NzaWJsZU1vdmVzIl0sIm1hcHBpbmdzIjoiOztBQUFBLElBQUlBLE1BQU0sU0FBTkEsR0FBTSxPQUEwQztBQUFBLE1BQXZDQyxHQUF1QyxRQUF2Q0EsR0FBdUM7QUFBQSxNQUFsQ0MsZ0JBQWtDLFFBQWxDQSxnQkFBa0M7QUFBQSxNQUFoQkMsVUFBZ0IsUUFBaEJBLFVBQWdCOztBQUNsREMsVUFBUUMsR0FBUixDQUFZSixHQUFaO0FBQ0EsU0FDRTtBQUFBO0FBQUE7QUFDR0EsUUFBSUssR0FBSixDQUFRLGdCQUFRO0FBQ2Y7Ozs7OztBQU1BLFVBQUlDLFNBQVNDLEtBQUtELE1BQUwsRUFBYjtBQUNBLFVBQUlFLE9BQU9GLE1BQVg7QUFDQSxVQUFJRyxpQkFBaUIsWUFBckI7QUFDQSxVQUFJQyxVQUFVRixJQUFkO0FBQ0EsVUFBSUcsTUFBSjtBQUNBLFVBQUlULFVBQUosRUFBZ0IsSUFBSVMsZUFBYUMsT0FBT04sTUFBUCxDQUFiLE1BQUo7QUFDaEIsVUFBSUMsS0FBS00sS0FBTCxLQUFlLE9BQW5CLEVBQTRCO0FBQzFCSiwwQkFBa0IsWUFBbEI7QUFDRCxPQUZELE1BRU8sSUFBSUYsS0FBS00sS0FBTCxLQUFlLE9BQW5CLEVBQTRCO0FBQ2pDSiwwQkFBa0IsWUFBbEI7QUFDRDtBQUNELFVBQUlGLEtBQUtPLFVBQVQsRUFBcUI7QUFDbkJILGlCQUFTSixLQUFLTyxVQUFMLENBQWdCSCxNQUF6QjtBQUNBLFlBQUlJLFFBQVFSLEtBQUtPLFVBQUwsQ0FBZ0JFLElBQTVCO0FBQ0FOLGtCQUFVVCxpQkFBaUJLLE1BQWpCLEVBQXlCQyxLQUFLTyxVQUFMLENBQWdCRyxhQUFoQixFQUF6QixFQUEwRFYsS0FBS00sS0FBL0QsQ0FBVjtBQUNBLFlBQUlFLFVBQVUsTUFBZCxFQUFxQjtBQUNuQkwsb0JBQVVULGlCQUFpQkssTUFBakIsRUFBeUJDLEtBQUtPLFVBQUwsQ0FBZ0JHLGFBQWhCLEVBQXpCLEVBQTBEVixLQUFLTSxLQUEvRCxFQUFzRSxJQUF0RSxDQUFWO0FBQ0Q7QUFDRixPQVBELE1BT087QUFDTDtBQUNEO0FBQ0QsYUFDRTtBQUFBO0FBQUEsVUFBSSxXQUFXSixjQUFmLEVBQStCLE9BQU9DLE9BQXRDO0FBQ0dDO0FBREgsT0FERjtBQUtELEtBakNBO0FBREgsR0FERjtBQXNDRCxDQXhDRCIsImZpbGUiOiJSb3cuanMiLCJzb3VyY2VzQ29udGVudCI6WyJ2YXIgUm93ID0gKHsgcm93LCBmaWx0ZXJWYWxpZE1vdmVzLCBzaG93Q29vcmRzfSkgPT4ge1xuICBjb25zb2xlLmxvZyhyb3cpXG4gIHJldHVybiAoXG4gICAgPHA+XG4gICAgICB7cm93Lm1hcCh0aWxlID0+IHtcbiAgICAgICAgLypcbiAgICAgICAgVE9ETzpcbiAgICAgICAgMi4gdGlsZSBvbiBob3ZlciBzaG91bGQgc2hvdyB3aGVyZSB0aGUgY2hlc3MgcGllY2VzIGNhbiBtb3ZlIGJ5IGhpZ2hsaWdodGluZyB0aG9zZSB0aWxlcyBibHVlLlxuICAgICAgICAzLiB0aWxlIG9uIGNsaWNrIHNob3VsZCBsZWF2ZSB0aGUgaGlnaGxpZ2h0cyBwZXJtYW5lbnRseS5cbiAgICAgICAgNC4gaGlnaGxpZ2h0ZWQgdGlsZSBjbGljayBzaG91bGQgbW92ZSB0aGUgcGllY2UgdGhlcmVcbiAgICAgICAgKi9cbiAgICAgICAgbGV0IGNvb3JkcyA9IHRpbGUuY29vcmRzKCk7XG4gICAgICAgIGxldCB0ZXh0ID0gY29vcmRzO1xuICAgICAgICBsZXQgY2hlc3NCb2FyZFRpbGUgPSBcImZsZXgtaXRlbSBcIjtcbiAgICAgICAgbGV0IHRvb2x0aXAgPSB0ZXh0O1xuICAgICAgICB2YXIgc3ltYm9sO1xuICAgICAgICBpZiAoc2hvd0Nvb3JkcykgdmFyIHN5bWJvbCA9IGBbJHtTdHJpbmcoY29vcmRzKX1dYDtcbiAgICAgICAgaWYgKHRpbGUuY29sb3IgPT09IFwiYmxhY2tcIikge1xuICAgICAgICAgIGNoZXNzQm9hcmRUaWxlICs9IFwiYmxhY2stdGlsZVwiO1xuICAgICAgICB9IGVsc2UgaWYgKHRpbGUuY29sb3IgPT09IFwid2hpdGVcIikge1xuICAgICAgICAgIGNoZXNzQm9hcmRUaWxlICs9IFwid2hpdGUtdGlsZVwiO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aWxlLm9jY3VwaWVkQnkpIHtcbiAgICAgICAgICBzeW1ib2wgPSB0aWxlLm9jY3VwaWVkQnkuc3ltYm9sXG4gICAgICAgICAgbGV0IHBpZWNlID0gdGlsZS5vY2N1cGllZEJ5LnR5cGU7XG4gICAgICAgICAgdG9vbHRpcCA9IGZpbHRlclZhbGlkTW92ZXMoY29vcmRzLCB0aWxlLm9jY3VwaWVkQnkucG9zc2libGVNb3ZlcygpLCB0aWxlLmNvbG9yKTtcbiAgICAgICAgICBpZiAocGllY2UgPT09ICdraW5nJyl7XG4gICAgICAgICAgICB0b29sdGlwID0gZmlsdGVyVmFsaWRNb3Zlcyhjb29yZHMsIHRpbGUub2NjdXBpZWRCeS5wb3NzaWJsZU1vdmVzKCksIHRpbGUuY29sb3IsIHRydWUpXG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIC8vdmFyIHN5bWJvbCA9IHRleHQ7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICA8bGkgY2xhc3NOYW1lPXtjaGVzc0JvYXJkVGlsZX0gdGl0bGU9e3Rvb2x0aXB9PlxuICAgICAgICAgICAge3N5bWJvbH1cbiAgICAgICAgICA8L2xpPlxuICAgICAgICApO1xuICAgICAgfSl9XG4gICAgPC9wPlxuICApO1xufTtcbiJdfQ==