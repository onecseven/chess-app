"use strict";

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

// Array.chunk = function(n) {
//   //chunk([1,2,3,4,5,6,7,8,9,10], 2) => [[1,2][3,4][5,6][7,8][9,10]]
//   return Array.range(Math.ceil(this.length / n)).map((x, i) =>
//     this.slice(i * n, i * n + n)
//   );
// };

// Array.range = function(n) {
//   // Array.range(5) --> [0,1,2,3,4]
//   return Array.apply(null, Array(n)).map((x, i) => i);
// };

var Move = function (_React$Component) {
  _inherits(Move, _React$Component);

  function Move(props) {
    _classCallCheck(this, Move);

    var _this = _possibleConstructorReturn(this, (Move.__proto__ || Object.getPrototypeOf(Move)).call(this, props));

    _this.state = {
      userInput: null
    };
    return _this;
  }

  _createClass(Move, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      return React.createElement(
        "form",
        {
          onSubmit: function onSubmit(e) {
            e.preventDefault();
            var re = new RegExp("[0-9]", "g");
            var coords = _this2.state.userInput;
            var stuff = coords.match(re).slice(0, 4);
            var ori = [stuff[0], stuff[1]];
            var dest = [stuff[2], stuff[3]];
            console.log('ORI', ori, "DEST", dest);
            _this2.props.move(ori, dest);
            _this2.setState({ userInput: "" });
          }
        },
        "Move Options",
        React.createElement("input", {
          name: "moves",
          type: "text",
          value: this.state.userInput,
          onChange: function onChange(e) {
            var temp = e.target.value;
            _this2.setState({ userInput: temp });
          }
        }),
        React.createElement(
          "button",
          { type: "submit" },
          " Submit "
        ),
        React.createElement("br", null),
        React.createElement(
          "button",
          {
            type: "toggle numbers",
            onClick: function onClick(e) {
              e.preventDefault();
              _this2.props.showCoords();
            }
          },
          "Toggle Coordinates"
        )
      );
    }
  }]);

  return Move;
}(React.Component);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9jb21wb25lbnRzL2RlYnVnLmpzeCJdLCJuYW1lcyI6WyJNb3ZlIiwicHJvcHMiLCJzdGF0ZSIsInVzZXJJbnB1dCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsInJlIiwiUmVnRXhwIiwiY29vcmRzIiwic3R1ZmYiLCJtYXRjaCIsInNsaWNlIiwib3JpIiwiZGVzdCIsImNvbnNvbGUiLCJsb2ciLCJtb3ZlIiwic2V0U3RhdGUiLCJ0ZW1wIiwidGFyZ2V0IiwidmFsdWUiLCJzaG93Q29vcmRzIiwiUmVhY3QiLCJDb21wb25lbnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0lBRU1BLEk7OztBQUNKLGdCQUFZQyxLQUFaLEVBQW1CO0FBQUE7O0FBQUEsNEdBQ1hBLEtBRFc7O0FBRWpCLFVBQUtDLEtBQUwsR0FBYTtBQUNYQyxpQkFBVztBQURBLEtBQWI7QUFGaUI7QUFLbEI7Ozs7NkJBQ1E7QUFBQTs7QUFDUCxhQUNFO0FBQUE7QUFBQTtBQUNFLG9CQUFVLHFCQUFLO0FBQ2JDLGNBQUVDLGNBQUY7QUFDQSxnQkFBSUMsS0FBSyxJQUFJQyxNQUFKLENBQVcsT0FBWCxFQUFvQixHQUFwQixDQUFUO0FBQ0EsZ0JBQUlDLFNBQVMsT0FBS04sS0FBTCxDQUFXQyxTQUF4QjtBQUNBLGdCQUFJTSxRQUFRRCxPQUFPRSxLQUFQLENBQWFKLEVBQWIsRUFBaUJLLEtBQWpCLENBQXVCLENBQXZCLEVBQTBCLENBQTFCLENBQVo7QUFDQSxnQkFBSUMsTUFBTSxDQUFDSCxNQUFNLENBQU4sQ0FBRCxFQUFXQSxNQUFNLENBQU4sQ0FBWCxDQUFWO0FBQ0EsZ0JBQUlJLE9BQU8sQ0FBQ0osTUFBTSxDQUFOLENBQUQsRUFBV0EsTUFBTSxDQUFOLENBQVgsQ0FBWDtBQUNBSyxvQkFBUUMsR0FBUixDQUFZLEtBQVosRUFBbUJILEdBQW5CLEVBQXdCLE1BQXhCLEVBQWdDQyxJQUFoQztBQUNBLG1CQUFLWixLQUFMLENBQVdlLElBQVgsQ0FBZ0JKLEdBQWhCLEVBQXFCQyxJQUFyQjtBQUNBLG1CQUFLSSxRQUFMLENBQWMsRUFBRWQsV0FBVyxFQUFiLEVBQWQ7QUFDRDtBQVhIO0FBQUE7QUFjRTtBQUNFLGdCQUFLLE9BRFA7QUFFRSxnQkFBSyxNQUZQO0FBR0UsaUJBQU8sS0FBS0QsS0FBTCxDQUFXQyxTQUhwQjtBQUlFLG9CQUFVLHFCQUFLO0FBQ2IsZ0JBQUllLE9BQU9kLEVBQUVlLE1BQUYsQ0FBU0MsS0FBcEI7QUFDQSxtQkFBS0gsUUFBTCxDQUFjLEVBQUVkLFdBQVdlLElBQWIsRUFBZDtBQUNEO0FBUEgsVUFkRjtBQXVCRTtBQUFBO0FBQUEsWUFBUSxNQUFLLFFBQWI7QUFBQTtBQUFBLFNBdkJGO0FBd0JFLHVDQXhCRjtBQXlCRTtBQUFBO0FBQUE7QUFDRSxrQkFBSyxnQkFEUDtBQUVFLHFCQUFTLG9CQUFLO0FBQ1pkLGdCQUFFQyxjQUFGO0FBQ0EscUJBQUtKLEtBQUwsQ0FBV29CLFVBQVg7QUFDRDtBQUxIO0FBQUE7QUFBQTtBQXpCRixPQURGO0FBcUNEOzs7O0VBN0NnQkMsTUFBTUMsUyIsImZpbGUiOiJkZWJ1Zy5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIEFycmF5LmNodW5rID0gZnVuY3Rpb24obikge1xuLy8gICAvL2NodW5rKFsxLDIsMyw0LDUsNiw3LDgsOSwxMF0sIDIpID0+IFtbMSwyXVszLDRdWzUsNl1bNyw4XVs5LDEwXV1cbi8vICAgcmV0dXJuIEFycmF5LnJhbmdlKE1hdGguY2VpbCh0aGlzLmxlbmd0aCAvIG4pKS5tYXAoKHgsIGkpID0+XG4vLyAgICAgdGhpcy5zbGljZShpICogbiwgaSAqIG4gKyBuKVxuLy8gICApO1xuLy8gfTtcblxuLy8gQXJyYXkucmFuZ2UgPSBmdW5jdGlvbihuKSB7XG4vLyAgIC8vIEFycmF5LnJhbmdlKDUpIC0tPiBbMCwxLDIsMyw0XVxuLy8gICByZXR1cm4gQXJyYXkuYXBwbHkobnVsbCwgQXJyYXkobikpLm1hcCgoeCwgaSkgPT4gaSk7XG4vLyB9O1xuXG5jbGFzcyBNb3ZlIGV4dGVuZHMgUmVhY3QuQ29tcG9uZW50IHtcbiAgY29uc3RydWN0b3IocHJvcHMpIHtcbiAgICBzdXBlcihwcm9wcyk7XG4gICAgdGhpcy5zdGF0ZSA9IHtcbiAgICAgIHVzZXJJbnB1dDogbnVsbFxuICAgIH07XG4gIH1cbiAgcmVuZGVyKCkge1xuICAgIHJldHVybiAoXG4gICAgICA8Zm9ybVxuICAgICAgICBvblN1Ym1pdD17ZSA9PiB7XG4gICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIGxldCByZSA9IG5ldyBSZWdFeHAoXCJbMC05XVwiLCBcImdcIik7XG4gICAgICAgICAgbGV0IGNvb3JkcyA9IHRoaXMuc3RhdGUudXNlcklucHV0O1xuICAgICAgICAgIGxldCBzdHVmZiA9IGNvb3Jkcy5tYXRjaChyZSkuc2xpY2UoMCwgNCk7XG4gICAgICAgICAgbGV0IG9yaSA9IFtzdHVmZlswXSwgc3R1ZmZbMV1dO1xuICAgICAgICAgIGxldCBkZXN0ID0gW3N0dWZmWzJdLCBzdHVmZlszXV07XG4gICAgICAgICAgY29uc29sZS5sb2coJ09SSScsIG9yaSwgXCJERVNUXCIsIGRlc3QpXG4gICAgICAgICAgdGhpcy5wcm9wcy5tb3ZlKG9yaSwgZGVzdCk7XG4gICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7IHVzZXJJbnB1dDogXCJcIiB9KTtcbiAgICAgICAgfX1cbiAgICAgID5cbiAgICAgICAgTW92ZSBPcHRpb25zXG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgIG5hbWU9XCJtb3Zlc1wiXG4gICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgIHZhbHVlPXt0aGlzLnN0YXRlLnVzZXJJbnB1dH1cbiAgICAgICAgICBvbkNoYW5nZT17ZSA9PiB7XG4gICAgICAgICAgICB2YXIgdGVtcCA9IGUudGFyZ2V0LnZhbHVlO1xuICAgICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7IHVzZXJJbnB1dDogdGVtcCB9KTtcbiAgICAgICAgICB9fVxuICAgICAgICAvPlxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIj4gU3VibWl0IDwvYnV0dG9uPlxuICAgICAgICA8YnIgLz5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJ0b2dnbGUgbnVtYmVyc1wiXG4gICAgICAgICAgb25DbGljaz17ZSA9PiB7XG4gICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgICB0aGlzLnByb3BzLnNob3dDb29yZHMoKTtcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAgVG9nZ2xlIENvb3JkaW5hdGVzXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9mb3JtPlxuICAgICk7XG4gIH1cbn1cbiJdfQ==