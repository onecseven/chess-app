"use strict";

var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Bishop = function (_Piece) {
  _inherits(Bishop, _Piece);

  function Bishop(_ref, color) {
    var _ref2 = _slicedToArray(_ref, 2),
        x = _ref2[0],
        y = _ref2[1];

    _classCallCheck(this, Bishop);

    var _this = _possibleConstructorReturn(this, (Bishop.__proto__ || Object.getPrototypeOf(Bishop)).call(this, [x, y], color));

    if (color === "white") {
      _this.symbol = "\u2657";
    } else if (color === "black") {
      _this.symbol = "\u265D    ";
    }
    _this.type = 'bishop';
    return _this;
  }

  _createClass(Bishop, [{
    key: "possibleMoves",
    value: function possibleMoves() {
      var _this2 = this;

      var result = [];
      var range = _.range(8);
      range.forEach(function (i) {
        var up = [_this2.x - i, _this2.y - i];
        var down = [_this2.x + i, _this2.y + i];
        var charm = [_this2.x + i, _this2.y - i];
        var strange = [_this2.x - i, _this2.y + i];
        if (up[0] >= 0 && up[0] <= 7 && up[1] >= 0 && up[1] <= 7) {
          result.push(up);
        }
        if (down[0] >= 0 && down[0] <= 7 && down[1] >= 0 && down[1] <= 7) {
          result.push(down);
        }
        if (charm[0] >= 0 && charm[0] <= 7 && charm[1] >= 0 && charm[1] <= 7) {
          result.push(charm);
        }
        if (strange[0] >= 0 && strange[0] <= 7 && strange[1] >= 0 && strange[1] <= 7) {
          result.push(strange);
        }
      });
      return result;
    }
  }]);

  return Bishop;
}(Piece);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9jb21wb25lbnRzL0Jpc2hvcC5qc3giXSwibmFtZXMiOlsiQmlzaG9wIiwiY29sb3IiLCJ4IiwieSIsInN5bWJvbCIsInR5cGUiLCJyZXN1bHQiLCJyYW5nZSIsIl8iLCJmb3JFYWNoIiwiaSIsInVwIiwiZG93biIsImNoYXJtIiwic3RyYW5nZSIsInB1c2giLCJQaWVjZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0lBQU1BLE07OztBQUNKLHdCQUFvQkMsS0FBcEIsRUFBMkI7QUFBQTtBQUFBLFFBQWRDLENBQWM7QUFBQSxRQUFYQyxDQUFXOztBQUFBOztBQUFBLGdIQUNuQixDQUFDRCxDQUFELEVBQUlDLENBQUosQ0FEbUIsRUFDWEYsS0FEVzs7QUFFekIsUUFBSUEsVUFBVSxPQUFkLEVBQXVCO0FBQ3JCLFlBQUtHLE1BQUw7QUFDRCxLQUZELE1BRU8sSUFBSUgsVUFBVSxPQUFkLEVBQXVCO0FBQzVCLFlBQUtHLE1BQUw7QUFDRDtBQUNELFVBQUtDLElBQUwsR0FBWSxRQUFaO0FBUHlCO0FBUTFCOzs7O29DQUNlO0FBQUE7O0FBQ2QsVUFBSUMsU0FBUyxFQUFiO0FBQ0EsVUFBSUMsUUFBUUMsRUFBRUQsS0FBRixDQUFRLENBQVIsQ0FBWjtBQUNBQSxZQUFNRSxPQUFOLENBQWMsVUFBQ0MsQ0FBRCxFQUFPO0FBQ25CLFlBQUlDLEtBQUssQ0FBQyxPQUFLVCxDQUFMLEdBQU9RLENBQVIsRUFBVyxPQUFLUCxDQUFMLEdBQU9PLENBQWxCLENBQVQ7QUFDQSxZQUFJRSxPQUFPLENBQUMsT0FBS1YsQ0FBTCxHQUFPUSxDQUFSLEVBQVcsT0FBS1AsQ0FBTCxHQUFPTyxDQUFsQixDQUFYO0FBQ0EsWUFBSUcsUUFBUSxDQUFDLE9BQUtYLENBQUwsR0FBT1EsQ0FBUixFQUFXLE9BQUtQLENBQUwsR0FBT08sQ0FBbEIsQ0FBWjtBQUNBLFlBQUlJLFVBQVUsQ0FBQyxPQUFLWixDQUFMLEdBQU9RLENBQVIsRUFBVyxPQUFLUCxDQUFMLEdBQU9PLENBQWxCLENBQWQ7QUFDQSxZQUFJQyxHQUFHLENBQUgsS0FBUyxDQUFULElBQWNBLEdBQUcsQ0FBSCxLQUFTLENBQXZCLElBQTRCQSxHQUFHLENBQUgsS0FBUyxDQUFyQyxJQUEwQ0EsR0FBRyxDQUFILEtBQVMsQ0FBdkQsRUFBMEQ7QUFDeERMLGlCQUFPUyxJQUFQLENBQVlKLEVBQVo7QUFDRDtBQUNELFlBQUlDLEtBQUssQ0FBTCxLQUFXLENBQVgsSUFBZ0JBLEtBQUssQ0FBTCxLQUFXLENBQTNCLElBQWdDQSxLQUFLLENBQUwsS0FBVyxDQUEzQyxJQUFnREEsS0FBSyxDQUFMLEtBQVcsQ0FBL0QsRUFBa0U7QUFDaEVOLGlCQUFPUyxJQUFQLENBQVlILElBQVo7QUFDRDtBQUNELFlBQUlDLE1BQU0sQ0FBTixLQUFZLENBQVosSUFBaUJBLE1BQU0sQ0FBTixLQUFZLENBQTdCLElBQWtDQSxNQUFNLENBQU4sS0FBWSxDQUE5QyxJQUFtREEsTUFBTSxDQUFOLEtBQVksQ0FBbkUsRUFBc0U7QUFDcEVQLGlCQUFPUyxJQUFQLENBQVlGLEtBQVo7QUFDRDtBQUNELFlBQUlDLFFBQVEsQ0FBUixLQUFjLENBQWQsSUFBbUJBLFFBQVEsQ0FBUixLQUFjLENBQWpDLElBQXNDQSxRQUFRLENBQVIsS0FBYyxDQUFwRCxJQUF5REEsUUFBUSxDQUFSLEtBQWMsQ0FBM0UsRUFBOEU7QUFDNUVSLGlCQUFPUyxJQUFQLENBQVlELE9BQVo7QUFDRDtBQUNGLE9BakJEO0FBa0JBLGFBQU9SLE1BQVA7QUFDRDs7OztFQWhDa0JVLEsiLCJmaWxlIjoiQmlzaG9wLmpzIiwic291cmNlc0NvbnRlbnQiOlsiY2xhc3MgQmlzaG9wIGV4dGVuZHMgUGllY2Uge1xuICBjb25zdHJ1Y3RvcihbeCwgeV0sIGNvbG9yKSB7XG4gICAgc3VwZXIoW3gsIHldLCBjb2xvcik7XG4gICAgaWYgKGNvbG9yID09PSBcIndoaXRlXCIpIHtcbiAgICAgIHRoaXMuc3ltYm9sID0gYOKZl2A7XG4gICAgfSBlbHNlIGlmIChjb2xvciA9PT0gXCJibGFja1wiKSB7XG4gICAgICB0aGlzLnN5bWJvbCA9IGDimZ0gICAgYDtcbiAgICB9XG4gICAgdGhpcy50eXBlID0gJ2Jpc2hvcCc7XG4gIH1cbiAgcG9zc2libGVNb3ZlcygpIHtcbiAgICBsZXQgcmVzdWx0ID0gW11cbiAgICB2YXIgcmFuZ2UgPSBfLnJhbmdlKDgpO1xuICAgIHJhbmdlLmZvckVhY2goKGkpID0+IHtcbiAgICAgIGxldCB1cCA9IFt0aGlzLngtaSwgdGhpcy55LWldO1xuICAgICAgbGV0IGRvd24gPSBbdGhpcy54K2ksIHRoaXMueStpXTtcbiAgICAgIGxldCBjaGFybSA9IFt0aGlzLngraSwgdGhpcy55LWldO1xuICAgICAgbGV0IHN0cmFuZ2UgPSBbdGhpcy54LWksIHRoaXMueStpXTtcbiAgICAgIGlmICh1cFswXSA+PSAwICYmIHVwWzBdIDw9IDcgJiYgdXBbMV0gPj0gMCAmJiB1cFsxXSA8PSA3ICl7XG4gICAgICAgIHJlc3VsdC5wdXNoKHVwKTtcbiAgICAgIH1cbiAgICAgIGlmIChkb3duWzBdID49IDAgJiYgZG93blswXSA8PSA3ICYmIGRvd25bMV0gPj0gMCAmJiBkb3duWzFdIDw9IDcgKXtcbiAgICAgICAgcmVzdWx0LnB1c2goZG93bik7XG4gICAgICB9XG4gICAgICBpZiAoY2hhcm1bMF0gPj0gMCAmJiBjaGFybVswXSA8PSA3ICYmIGNoYXJtWzFdID49IDAgJiYgY2hhcm1bMV0gPD0gNyApe1xuICAgICAgICByZXN1bHQucHVzaChjaGFybSk7XG4gICAgICB9XG4gICAgICBpZiAoc3RyYW5nZVswXSA+PSAwICYmIHN0cmFuZ2VbMF0gPD0gNyAmJiBzdHJhbmdlWzFdID49IDAgJiYgc3RyYW5nZVsxXSA8PSA3ICl7XG4gICAgICAgIHJlc3VsdC5wdXNoKHN0cmFuZ2UpO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cbn1cbiJdfQ==