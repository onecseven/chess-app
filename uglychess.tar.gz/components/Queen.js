"use strict";

var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Queen = function (_Piece) {
  _inherits(Queen, _Piece);

  function Queen(_ref, color) {
    var _ref2 = _slicedToArray(_ref, 2),
        x = _ref2[0],
        y = _ref2[1];

    _classCallCheck(this, Queen);

    var _this = _possibleConstructorReturn(this, (Queen.__proto__ || Object.getPrototypeOf(Queen)).call(this, [x, y], color));

    if (color === "white") {
      _this.symbol = "\u2655";
    } else if (color === "black") {
      _this.symbol = "\u265B";
    }
    _this.type = "queen";
    return _this;
  }

  _createClass(Queen, [{
    key: "possibleMoves",
    value: function possibleMoves() {
      var _this2 = this;

      //bishop code
      var result = [];
      var range = _.range(8);
      range.forEach(function (i) {
        var up = [_this2.x - i, _this2.y - i];
        var down = [_this2.x + i, _this2.y + i];
        var charm = [_this2.x + i, _this2.y - i];
        var strange = [_this2.x - i, _this2.y + i];
        if (up[0] >= 0 && up[0] <= 7 && up[1] >= 0 && up[1] <= 7) {
          result.push(up);
        }
        if (down[0] >= 0 && down[0] <= 7 && down[1] >= 0 && down[1] <= 7) {
          result.push(down);
        }
        if (charm[0] >= 0 && charm[0] <= 7 && charm[1] >= 0 && charm[1] <= 7) {
          result.push(charm);
        }
        if (strange[0] >= 0 && strange[0] <= 7 && strange[1] >= 0 && strange[1] <= 7) {
          result.push(strange);
        }
      });

      var range = _.range(8);
      var rook1 = [];
      var rook2 = [];
      range.forEach(function (i) {
        rook1.push([_this2.x, i]);
        rook2.push([i, _this2.y]);
      });
      var final = rook1.concat(rook2);
      return final.concat(result);
    }
  }]);

  return Queen;
}(Piece);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9jb21wb25lbnRzL1F1ZWVuLmpzeCJdLCJuYW1lcyI6WyJRdWVlbiIsImNvbG9yIiwieCIsInkiLCJzeW1ib2wiLCJ0eXBlIiwicmVzdWx0IiwicmFuZ2UiLCJfIiwiZm9yRWFjaCIsInVwIiwiaSIsImRvd24iLCJjaGFybSIsInN0cmFuZ2UiLCJwdXNoIiwicm9vazEiLCJyb29rMiIsImZpbmFsIiwiY29uY2F0IiwiUGllY2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztJQUFNQSxLOzs7QUFDSix1QkFBb0JDLEtBQXBCLEVBQTJCO0FBQUE7QUFBQSxRQUFkQyxDQUFjO0FBQUEsUUFBWEMsQ0FBVzs7QUFBQTs7QUFBQSw4R0FDbkIsQ0FBQ0QsQ0FBRCxFQUFJQyxDQUFKLENBRG1CLEVBQ1hGLEtBRFc7O0FBRXpCLFFBQUlBLFVBQVUsT0FBZCxFQUF1QjtBQUNyQixZQUFLRyxNQUFMO0FBQ0QsS0FGRCxNQUVPLElBQUlILFVBQVUsT0FBZCxFQUF1QjtBQUM1QixZQUFLRyxNQUFMO0FBQ0Q7QUFDRCxVQUFLQyxJQUFMLEdBQVksT0FBWjtBQVB5QjtBQVExQjs7OztvQ0FDZTtBQUFBOztBQUNkO0FBQ0EsVUFBSUMsU0FBUyxFQUFiO0FBQ0EsVUFBSUMsUUFBUUMsRUFBRUQsS0FBRixDQUFRLENBQVIsQ0FBWjtBQUNBQSxZQUFNRSxPQUFOLENBQWMsYUFBSztBQUNqQixZQUFJQyxLQUFLLENBQUMsT0FBS1IsQ0FBTCxHQUFTUyxDQUFWLEVBQWEsT0FBS1IsQ0FBTCxHQUFTUSxDQUF0QixDQUFUO0FBQ0EsWUFBSUMsT0FBTyxDQUFDLE9BQUtWLENBQUwsR0FBU1MsQ0FBVixFQUFhLE9BQUtSLENBQUwsR0FBU1EsQ0FBdEIsQ0FBWDtBQUNBLFlBQUlFLFFBQVEsQ0FBQyxPQUFLWCxDQUFMLEdBQVNTLENBQVYsRUFBYSxPQUFLUixDQUFMLEdBQVNRLENBQXRCLENBQVo7QUFDQSxZQUFJRyxVQUFVLENBQUMsT0FBS1osQ0FBTCxHQUFTUyxDQUFWLEVBQWEsT0FBS1IsQ0FBTCxHQUFTUSxDQUF0QixDQUFkO0FBQ0EsWUFBSUQsR0FBRyxDQUFILEtBQVMsQ0FBVCxJQUFjQSxHQUFHLENBQUgsS0FBUyxDQUF2QixJQUE0QkEsR0FBRyxDQUFILEtBQVMsQ0FBckMsSUFBMENBLEdBQUcsQ0FBSCxLQUFTLENBQXZELEVBQTBEO0FBQ3hESixpQkFBT1MsSUFBUCxDQUFZTCxFQUFaO0FBQ0Q7QUFDRCxZQUFJRSxLQUFLLENBQUwsS0FBVyxDQUFYLElBQWdCQSxLQUFLLENBQUwsS0FBVyxDQUEzQixJQUFnQ0EsS0FBSyxDQUFMLEtBQVcsQ0FBM0MsSUFBZ0RBLEtBQUssQ0FBTCxLQUFXLENBQS9ELEVBQWtFO0FBQ2hFTixpQkFBT1MsSUFBUCxDQUFZSCxJQUFaO0FBQ0Q7QUFDRCxZQUFJQyxNQUFNLENBQU4sS0FBWSxDQUFaLElBQWlCQSxNQUFNLENBQU4sS0FBWSxDQUE3QixJQUFrQ0EsTUFBTSxDQUFOLEtBQVksQ0FBOUMsSUFBbURBLE1BQU0sQ0FBTixLQUFZLENBQW5FLEVBQXNFO0FBQ3BFUCxpQkFBT1MsSUFBUCxDQUFZRixLQUFaO0FBQ0Q7QUFDRCxZQUNFQyxRQUFRLENBQVIsS0FBYyxDQUFkLElBQ0FBLFFBQVEsQ0FBUixLQUFjLENBRGQsSUFFQUEsUUFBUSxDQUFSLEtBQWMsQ0FGZCxJQUdBQSxRQUFRLENBQVIsS0FBYyxDQUpoQixFQUtFO0FBQ0FSLGlCQUFPUyxJQUFQLENBQVlELE9BQVo7QUFDRDtBQUNGLE9BdEJEOztBQXdCQSxVQUFJUCxRQUFRQyxFQUFFRCxLQUFGLENBQVEsQ0FBUixDQUFaO0FBQ0EsVUFBSVMsUUFBUSxFQUFaO0FBQ0EsVUFBSUMsUUFBUSxFQUFaO0FBQ0FWLFlBQU1FLE9BQU4sQ0FBYyxhQUFLO0FBQ2pCTyxjQUFNRCxJQUFOLENBQVcsQ0FBQyxPQUFLYixDQUFOLEVBQVNTLENBQVQsQ0FBWDtBQUNBTSxjQUFNRixJQUFOLENBQVcsQ0FBQ0osQ0FBRCxFQUFJLE9BQUtSLENBQVQsQ0FBWDtBQUNELE9BSEQ7QUFJQSxVQUFJZSxRQUFRRixNQUFNRyxNQUFOLENBQWFGLEtBQWIsQ0FBWjtBQUNBLGFBQU9DLE1BQU1DLE1BQU4sQ0FBYWIsTUFBYixDQUFQO0FBQ0Q7Ozs7RUEvQ2lCYyxLIiwiZmlsZSI6IlF1ZWVuLmpzIiwic291cmNlc0NvbnRlbnQiOlsiY2xhc3MgUXVlZW4gZXh0ZW5kcyBQaWVjZSB7XG4gIGNvbnN0cnVjdG9yKFt4LCB5XSwgY29sb3IpIHtcbiAgICBzdXBlcihbeCwgeV0sIGNvbG9yKTtcbiAgICBpZiAoY29sb3IgPT09IFwid2hpdGVcIikge1xuICAgICAgdGhpcy5zeW1ib2wgPSBg4pmVYDtcbiAgICB9IGVsc2UgaWYgKGNvbG9yID09PSBcImJsYWNrXCIpIHtcbiAgICAgIHRoaXMuc3ltYm9sID0gYOKZm2A7XG4gICAgfVxuICAgIHRoaXMudHlwZSA9IFwicXVlZW5cIjtcbiAgfVxuICBwb3NzaWJsZU1vdmVzKCkge1xuICAgIC8vYmlzaG9wIGNvZGVcbiAgICBsZXQgcmVzdWx0ID0gW107XG4gICAgdmFyIHJhbmdlID0gXy5yYW5nZSg4KTtcbiAgICByYW5nZS5mb3JFYWNoKGkgPT4ge1xuICAgICAgbGV0IHVwID0gW3RoaXMueCAtIGksIHRoaXMueSAtIGldO1xuICAgICAgbGV0IGRvd24gPSBbdGhpcy54ICsgaSwgdGhpcy55ICsgaV07XG4gICAgICBsZXQgY2hhcm0gPSBbdGhpcy54ICsgaSwgdGhpcy55IC0gaV07XG4gICAgICBsZXQgc3RyYW5nZSA9IFt0aGlzLnggLSBpLCB0aGlzLnkgKyBpXTtcbiAgICAgIGlmICh1cFswXSA+PSAwICYmIHVwWzBdIDw9IDcgJiYgdXBbMV0gPj0gMCAmJiB1cFsxXSA8PSA3KSB7XG4gICAgICAgIHJlc3VsdC5wdXNoKHVwKTtcbiAgICAgIH1cbiAgICAgIGlmIChkb3duWzBdID49IDAgJiYgZG93blswXSA8PSA3ICYmIGRvd25bMV0gPj0gMCAmJiBkb3duWzFdIDw9IDcpIHtcbiAgICAgICAgcmVzdWx0LnB1c2goZG93bik7XG4gICAgICB9XG4gICAgICBpZiAoY2hhcm1bMF0gPj0gMCAmJiBjaGFybVswXSA8PSA3ICYmIGNoYXJtWzFdID49IDAgJiYgY2hhcm1bMV0gPD0gNykge1xuICAgICAgICByZXN1bHQucHVzaChjaGFybSk7XG4gICAgICB9XG4gICAgICBpZiAoXG4gICAgICAgIHN0cmFuZ2VbMF0gPj0gMCAmJlxuICAgICAgICBzdHJhbmdlWzBdIDw9IDcgJiZcbiAgICAgICAgc3RyYW5nZVsxXSA+PSAwICYmXG4gICAgICAgIHN0cmFuZ2VbMV0gPD0gN1xuICAgICAgKSB7XG4gICAgICAgIHJlc3VsdC5wdXNoKHN0cmFuZ2UpO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgdmFyIHJhbmdlID0gXy5yYW5nZSg4KTtcbiAgICB2YXIgcm9vazEgPSBbXTtcbiAgICB2YXIgcm9vazIgPSBbXTtcbiAgICByYW5nZS5mb3JFYWNoKGkgPT4ge1xuICAgICAgcm9vazEucHVzaChbdGhpcy54LCBpXSk7XG4gICAgICByb29rMi5wdXNoKFtpLCB0aGlzLnldKTtcbiAgICB9KTtcbiAgICB2YXIgZmluYWwgPSByb29rMS5jb25jYXQocm9vazIpO1xuICAgIHJldHVybiBmaW5hbC5jb25jYXQocmVzdWx0KTtcbiAgfVxufVxuIl19