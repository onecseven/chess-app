"use strict";

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Tile = function () {
  function Tile(coords) {
    _classCallCheck(this, Tile);

    this.x = coords[0];
    this.y = coords[1];
    if (this.x % 2 === 0 && this.y % 2 === 0) {
      this.color = "black";
    } else if (this.x % 2 === 1 && this.y % 2 === 1) {
      this.color = "black";
    } else {
      this.color = "white";
    }
    this.occupiedBy = null;
  }
  //do we need this?


  _createClass(Tile, [{
    key: "color",
    value: function color() {
      return this.color;
    }
  }, {
    key: "coords",
    value: function coords() {
      return [this.x, this.y];
    }
  }, {
    key: "occupiedBy",
    value: function occupiedBy() {
      return this.occupiedBy;
    }
  }]);

  return Tile;
}();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9jb21wb25lbnRzL1RpbGUuanN4Il0sIm5hbWVzIjpbIlRpbGUiLCJjb29yZHMiLCJ4IiwieSIsImNvbG9yIiwib2NjdXBpZWRCeSJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0lBQU1BLEk7QUFDSixnQkFBWUMsTUFBWixFQUFvQjtBQUFBOztBQUNsQixTQUFLQyxDQUFMLEdBQVNELE9BQU8sQ0FBUCxDQUFUO0FBQ0EsU0FBS0UsQ0FBTCxHQUFTRixPQUFPLENBQVAsQ0FBVDtBQUNBLFFBQUksS0FBS0MsQ0FBTCxHQUFTLENBQVQsS0FBZSxDQUFmLElBQW9CLEtBQUtDLENBQUwsR0FBUyxDQUFULEtBQWUsQ0FBdkMsRUFBMEM7QUFDeEMsV0FBS0MsS0FBTCxHQUFhLE9BQWI7QUFDRCxLQUZELE1BRU8sSUFBSSxLQUFLRixDQUFMLEdBQVMsQ0FBVCxLQUFlLENBQWYsSUFBb0IsS0FBS0MsQ0FBTCxHQUFTLENBQVQsS0FBZSxDQUF2QyxFQUEwQztBQUMvQyxXQUFLQyxLQUFMLEdBQWEsT0FBYjtBQUNELEtBRk0sTUFFQTtBQUNMLFdBQUtBLEtBQUwsR0FBYSxPQUFiO0FBQ0Q7QUFDRCxTQUFLQyxVQUFMLEdBQWtCLElBQWxCO0FBQ0Q7QUFDRDs7Ozs7NEJBQ1E7QUFDTixhQUFPLEtBQUtELEtBQVo7QUFDRDs7OzZCQUNRO0FBQ1AsYUFBTyxDQUFDLEtBQUtGLENBQU4sRUFBUyxLQUFLQyxDQUFkLENBQVA7QUFDRDs7O2lDQUNZO0FBQ1gsYUFBTyxLQUFLRSxVQUFaO0FBQ0QiLCJmaWxlIjoiVGlsZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImNsYXNzIFRpbGUge1xuICBjb25zdHJ1Y3Rvcihjb29yZHMpIHtcbiAgICB0aGlzLnggPSBjb29yZHNbMF07XG4gICAgdGhpcy55ID0gY29vcmRzWzFdO1xuICAgIGlmICh0aGlzLnggJSAyID09PSAwICYmIHRoaXMueSAlIDIgPT09IDApIHtcbiAgICAgIHRoaXMuY29sb3IgPSBcImJsYWNrXCI7XG4gICAgfSBlbHNlIGlmICh0aGlzLnggJSAyID09PSAxICYmIHRoaXMueSAlIDIgPT09IDEpIHtcbiAgICAgIHRoaXMuY29sb3IgPSBcImJsYWNrXCI7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuY29sb3IgPSBcIndoaXRlXCI7XG4gICAgfVxuICAgIHRoaXMub2NjdXBpZWRCeSA9IG51bGw7XG4gIH1cbiAgLy9kbyB3ZSBuZWVkIHRoaXM/XG4gIGNvbG9yKCkge1xuICAgIHJldHVybiB0aGlzLmNvbG9yO1xuICB9XG4gIGNvb3JkcygpIHtcbiAgICByZXR1cm4gW3RoaXMueCwgdGhpcy55XTtcbiAgfVxuICBvY2N1cGllZEJ5KCkge1xuICAgIHJldHVybiB0aGlzLm9jY3VwaWVkQnk7XG4gIH1cbn1cbiJdfQ==